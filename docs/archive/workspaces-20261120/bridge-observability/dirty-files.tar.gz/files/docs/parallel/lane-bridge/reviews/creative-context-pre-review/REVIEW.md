# A03 Creative / Context 只读预审

输入：实际MAIN `/mnt/c/workspace/videoworkline/Narralens-agents/main-integration`，HEAD `4b683a12d4c7dff570c7e240a3fc236c694e6896` 加未提交A03修改。精确七份输入见 input-hashes.json。本人未运行测试、Host、浏览器或ffmpeg，未修改MAIN；parent session42040与旧模块回归属于MAIN执行，本文不预判结果。

当前结论：**NEEDS_WORK（未冻结预审）**，有两条可复现具体路径。不存在新写执行许可或整体A通过结论。

## C-R1：Context只锁run行，遗漏实际投影读取的授权事实（P2一致性）

project-context-service.ts 捕获 `canonicalDigest(tx.list('run'))`，随后调用workflow.readCurrentRun，再await native.read，最后仅比较run行digest。但FixedWorkflowService.#projectRun除run还读取execution_grant及trusted_confirmation；既有authorizeRun L528写execution_grant和idempotency，不更新run行。

确定性复现方案（未执行）：建立有效run，context.read得到authorization:null的activeRun后在NativeContextPort.read gate暂停；另用真实FixedWorkflowService.authorizeRun完成授权；放行gate。最终runToken仍相同，context返回旧authorization:null，未拒观察期间的授权变化。即便未注入native，`await native?.read(...)`也让出微任务；不能把run row未变等同完整projection未变。

当前CreationApplication仅注册workflow只读，authorize生产HTTP尚未挂，因此本项不是当前HTTP越权或实际执行漏洞；它是新Context只读组合已存在的混版本风险，授权producer挂载前应修正。建议在最终同一读事务重投影current run，或对实际完整projection依赖（run/grant/confirmation）做首尾token校验。不要只增加不影响run的版本常数，也不要缓存pre-await授权。补无变成功与并发授权负向。

初始代码绑定：Context `a095e0e699efccf440b4bbcf71f669c0314110254d22c16fe8051e82eee8b7f8`；FixedWorkflow `e365e4dac2636d6a680dc9326786a1b9a1776b0bf270f5c363df23824ec869bd`。

## C-R2：其他active job的缺producer分支实际落409而非503（P2协议行为）

Context activeJobs对项目所有非终态Job逐个调用creation.receiptForJob，期待null时抛CAPABILITY_UNAVAILABLE。但是ProjectCreationStore.receiptForJob按project/principal找到该工程bootstrap后，若`reservation.job_id !== jobId`先throw conflict()。因此同工程合法非creator queued Job到来时返回409 REVISION_CONFLICT，代码到不了显式503；与release所述“其他producer缺失明确unavailable不藏”不一致。

可复现方案（未执行）：创建成功工程，在其真实PersistentJobStore.create登记另一个queued任务，如proposal_comparison，再HTTP GET context。权限与commit均有效，activeJobs含非creator，预期503但当前先409。建议先明确辨认creator job，其他任务缺producer走503；creator自身记录错配仍保留409，不通过跳过未知Job/返回空列表隐藏实际状态。加此负向及正常creator receipt成功对照。

## 权限、引用与原子性核对

生产CreationApplication必注入authority.assertArtifact，没有保留可跳过hook的生产artifact route。CreativeService在ProductRepository事务内先access owner再查幂等；命中原key只回原响应，不因后来创作闭包变动重写历史。新请求在同事务write阶段核current intake head及完整creativeInputClosure digest、project内不可变ref版本/hash/实际内容hash，随后写version/head CAS/event/outbox/command；authority同步读的是同一SQLite连接，未在权限检查与写之间引入await。跨owner即便知道原idempotency key也先404，未发现重放越权路径。

ref的intake namespace仅限该created工程对应Intake；其他id只能在本project artifact_version中解析。禁止artifact_id与该intake id冲突；intake同名artifact歧义显式拒绝。正文hash与声明ref一致，缺ref/错误hash不会默默相信metadata。Script段落/Storyboard镜头ID重复拒绝；Storyboard paragraph必须来自显式input_refs内的Script，asset_id必须在当前Brief一致的local资产策略中。当前未要求artifact ref必须指head，允许显式历史immutable版本；未发现把合法历史ref误拒的过度约束。素材绑定只证明内容策略，不是license/执行能力授权。

本轮没有证据支持新增“恰好一个Script ref”的冻结规则；当前paragraph集合可来自多个声明Script，若未来Run要求单一Script，应在该明确Run scope核谱系，不临时改冻结ArtifactPut规则。

## 观察与能力边界

Context先核owner，再resolve真实created origin/active commit/binding/source fact；实际固定OpenFilm inspect必须匹配source_digest且无problems，最终核commit revision/snapshot/digest/control revision/recovery gate未漂移。artifact heads在最后同一事务读取并hash核immutable版本；异步inspect之前的旧project不能混入新commit。

无trusted native bridge时selection=null/version0、ack=null、sync=unknown；发现durable ack却没有正式producer则503，不把Host revision抄成loaded。未来注入port会核NativeAck/schema、project及当前bridge session/generation/revision/snapshot/digest/selection版本匹配才允许loaded/selection。该未来分支本轮生产并未注入，不能称真实native握手已通过。

active_run沿用原WorkflowService current-run选择规则，未建立第二run指针；无run为null，缺执行producer仍unregistered/capabilities空。当前只能识别creator active job，其他job必须unavailable而非伪空列表，见C-R2。workflow只读handler核工程owner；native channel仍拒绝。Content草稿写不改author source或project revision，不等于发布/执行批准。

## 测试证据范围

已读三项真实HTTP集成测试源码：Script/Storyboard写+Context+幂等/源未改，跨owner/坏ref/hash/input无副作用，Intake更新后历史重放/新stale写拒。第三测试标题提到dangling storyboard paragraphs但当前函数体未实际构造该负向，不能把名称当已覆盖证据。缺并发授权混版本及非creator Job unavailable负向。以上均是源码观察，独立测试NOT_RUN。

后续新字节需重新绑定；修复后也只形成A03组件/接缝候选，不签A轮、原生UI、完整影片或双导出通过。


## R4 修正只读复核（未冻结）

新输入绑定 r4-input-hashes.json。本人没有运行测试或改MAIN；MAIN报告R3 tsc0/3files55tests通过，仅记MAIN执行。R4 session82206仍为MAIN实际执行，本报告不预签其结果。

**C-R1 SOURCE_ADDRESSED。** Context去掉异步runToken/readCurrentRun拼装，最后同一个ProductSqliteRepository事务内调用同步readCurrentRunInTransaction，run selection/grant/confirmation与artifact/job/commit事实在同一事务读取。新增observer组件case在NativeContextPort.read内真实authorizeRun，再断言context返回该authorization，正好针对旧投影窗口。该case用真实持久SQLite，但eligibility/rights/capability来自明确标注的synthetic fixture，不证明生产Run合法性或执行已挂。

**C-R2 SOURCE_ADDRESSED。** Context先取creator reservation，对任意非creator job_id直接CAPABILITY_UNAVAILABLE，再调用receiptForJob；错误任务不再先落creator内部conflict。新增真实PersistentJobStore render queued Job后HTTP Context503，未过滤为假空数组。

**artifact receipt PROJECT字段修正已核。** CreativeService.putArtifact记录项目scope幂等时，receipt以前由通用helper固定project_id:null；新代码只在artifact分支覆为request.project_id，与SQLite ledger的scope一致。旧通用Intake/principal receipt不受影响。真正artifact version/head/event/outbox/ledger仍同事务；MAIN最初HTTP400证据应保留，MemoryRepo纯域成功不能替代本生产SQL验证。

### C-R3：未来issued授权仍被投影为active（P2时间一致性，待修）

新#projectRun核confirmation存在及purpose/channel/actor/action/input/expiry与run/grant绑定，核issued_at<expires_at；排序优先expires_at>now，再issued_at最新，过期grant投影expired。这解决旧expired仍active及任意选中过期前任的问题。但它没有检查confirmation.issued_at<=now，故未来issued且expires仍未来的确认会被显示active，并可因issued最新优先于当前已有效grant。

可控复现方案（未执行）：沿现有observer synthetic fixture在t成功authorizeRun，然后setNow(t-1)，再readCurrentRun，当前代码返回state active。或并存一个已有效grant及一个未来issued/未来expires的grant，未来确认排序更高。此可来自受控clock回退或异常持久事实，不需要把过期token当权限。建议对未来issued明确RUN_SCOPE_REQUIRED/不可用，不能伪active；增加未来issued负向和当前有效成功对照。#requireActiveGrant旧执行检查本身只看grant state/expiry/owner，本轮执行producer未注册，所以本报告不把该observer问题夸大成当前生产HTTP可越权执行。

C-R3初始绑定：FixedWorkflow `81eba53eebc0100b4b5dbef213cafb477ec254194fe9d2b7b8db568b2aefc7bc`。后续修正必须另绑字节。

### 新测试与剩余门

核到同owner第二真实project artifact ref/hash也404；问题current closure变化拒新旧digest、历史原key重放不改、current闭包允许新草稿；真实source字节漂移Context409且跨owner仍先404；并发observer授权及授权过期/新授权优先。第三旧测试标题对应的dangling paragraph断言若未实加，仍不按标题计覆盖。

当前scope仍限定created工程、draft内容和只读observer。trusted native port未生产注入，所以unknown/null不能当native载入证据；Run eligibility fixture不等于真实rights/四能力/dispatch。未冻结源码暂为NEEDS_WORK（C-R3时间投影边界）；其余原两点及artifact receipt定向源码修正成立，不签整体A。


## C-R3修正 / safe-control / FIFO 只读复核（R6未冻结）

输入绑定 r6-input-hashes.json，HEAD仍4b683a1加MAIN未提交源码。本人未执行测试/Host，未改MAIN。MAIN报告R5 tsc0、7files115/115，记为MAIN执行；R6 session80884仍在回归M2.1/golden，结果不能由本文预签。

**C-R3 SOURCE_ADDRESSED。** 新trustedGrantConfirmation统一核confirmation的purpose/channel/actor/action_digest/input_digest/expires_at与run/grant绑定，issued/expires/now整数、issued<=now且issued<expires；future或缺confirmation返回null。observer严格投影将null拒RUN_SCOPE_REQUIRED；readGuardFacts不猜issued时间，直接取同一真实confirmation，缺/未来时grant=null。ExecutionGuardFacts内部issued_at必填，action assertGrant明确拒missing/future/invalid interval。过期仍可读为expired，排序优先当前未过期，再按真实issued时间和稳定id。旧pure fixture仅补已有NOW-60，不改变公开CP/DTO。

### C-R4：真实safe-control被严格response投影反向阻断（P1收紧操作回归，待修）

纯guardExecution正确在assertGrant前处理safe_control，因此未来/缺issued时单纯guard的cancel不会被挡；readGuardFacts返回grant=null也不抛，可以给safe-control消费。但实际FixedWorkflowService.#controlRun在safeControl时跳过#requireActiveGrant，写入收紧run/event后，L657仍调用严格#projectRun(tx,updated)。该投影遍历active grant并在trustedGrantConfirmation=null时抛RUN_SCOPE_REQUIRED。于是future-issued/缺可信确认的active grant会让pauseRun/cancelRun整个事务回滚；没有真正收紧，虽纯guard测试通过。

可控复现方案（未执行）：沿现有持久observerRun fixture于t授权，setNow(t-1)；readCurrentRun应拒（正确）；接着调用实际pauseRun或cancelRun，当前同样在结果投影抛错，run/event/receipt全部回滚（错误）。可按独立fixture分别测pause与cancel，避免cancel终态影响pause。当前新测试仅调用guardExecution safe_control，不覆盖完整service路径。

建议仅在safe-control结果投影对不可用授权回null，绝不伪active；普通observer继续严格拒绝，action执行仍要求有效grant/issued。或以其他不依赖坏grant的真实收紧回执方式保持冻结WorkflowRun合法。补真实SQLite service pause/cancel成功、结果authorization=null、持久run已收紧、无重复事件，以及未来issued action仍拒的对照。生产scope/owner检查继续保留，不能为收紧而开放跨project控制。该缺口是服务模块路径，生产run control producer目前仍未挂，本文不称已有HTTP用户被阻断或已能越权执行。

C-R4初始绑定FixedWorkflow `03380bd6620674956176030769687b67a67e105198dae9fe4cdc47e79800f35d`。

### SourceDigest FIFO 修法

实际loadFile保留原canonical realpath/根内边界和relative/hash/domain；从readFile(path)改为open(O_RDONLY|O_NONBLOCK|O_NOFOLLOW)，在同一个FileHandle上stat判regular，再readFile，finally close。FIFO即使无writer也不会在open阶段占住线程等待；非regular在读内容前拒，叶路径在realpath后变symlink会被NOFOLLOW拒。未使用先stat再重新open的双路径窗口。正常regular文件仍按原bytes/hash语义计算，没有改摘要域来调绿golden。

新增真实Host请求测试用本测试root内mkfifo替换source film.html，以3秒timeout检查请求不挂并503；MAIN保留旧readFile真实阻塞失败日志。此是实际修法/测试源码复核，M2.1/golden运行结果依MAIN本轮终态，本人未重跑。它不承诺对外部并发写regular文件提供不可变快照，原有Coordinator、snapshot及proof边界仍承担该责任。

当前C-R3关闭源码门，C-R4待修，因此本未冻结预审仍NEEDS_WORK；不签A03/A或真实native/rights/Run生产证据。


## C-R4修正及继续scope审查（未冻结）

输入见safe-control-fix-input-hashes.json，实际MAIN HEAD仍4b683a1加dirty。本人未测试、未改MAIN。MAIN提供main-safe-control-before tests.exit1作为其真实pause/cancel回滚复现；当前exec71954在MAIN单worker执行，本文不预签结果。

**C-R4 SOURCE_ADDRESSED。** #projectRun改flatMap：future/missing/mismatched trusted confirmation从候选授权移除，无可用候选时authorization:null，不再在safe-control结果投影抛错。#requireActiveGrant新增同一trustedGrantConfirmation严格检查并保留state/expiry/actor检查，故未把读侧容错变成执行放行。普通observer未来授权现在也返回null而非抛；这是诚实的“无可用授权”投影，不再伪active，符合C-R3原问题的修复目标。旧报告要求普通observer严格抛错是一个修复选项，不是冻结合同必须要求；该NULL方案无需为保留该选项牺牲安全收紧。

新两个实际SQLite service case分别调用pauseRun/cancelRun，核返回paused/cancelled、authorization:null及持久run相应终态，再核startRun拒RUN_SCOPE_REQUIRED；比旧单纯guard safe_control case更完整。当前源码读侧/执行侧边界正确，等待MAIN实际终态及冻结独立验证。C-R4修正初始绑定FixedWorkflow `87d32389c94613e96e7835a953dd072c05507a39722e7425660031356838c10f`。

### C-R5：生产content.relay可错标任意project关联（P2 scope/内容完整性）

CreativeService.relayContentDecision实际事务先核assertIntakeOwner，然后写Intake作用域决定；它不验证request.project_id。返回ContentDecision直接复制该project_id，Production CreationApplication又直接注册creativeHandlers，没有为content.relay包同工程authority。

可复现方案（未执行）：principal A有自己Intake及正确闭包；请求content.relay时将nullable project_id填principal B的真实project ID，或填不存在的ID。当前仍可200，返回的ContentDecision.project_id声称关联他人工程，虽然该决定实际只由A自己的Intake产生。相同owner的两个项目也能将与工程B不对应的IntakeA错标到B。

范围：这不会直接修改B的工程、泄漏B内容或授予执行；持久intake_content_decision也没有project字段。因此它是已经生产注册的wire响应scope假关联问题，不夸大成执行越权。A03现在把内容决定、artifact/context纳入同一工程生产接线，应避免将任意body字段用作project authority。

建议当project_id非null时，在同一事务中先核owned committed工程及其creation.request.intake_id与request.intake_id匹配，再幂等lookup；null preproject继续允许。不能仅把project_id抹null以隐藏调用者错误或把错误关联存入旧回执；重放亦应先核access，保持原响应语义。加自有匹配project成功、null preproject成功、foreign/missing/自身不匹配Intake project拒绝及无新增decision/event/receipt对照。这里的工程绑定由MAIN authority供应，不要求底层旧MemoryRepo纯内容测试自行造生产项目。

其余再读：artifact access-before-replay/new-write hook仍为同事务，Ref仍限自身Intake/本project immutable artifact；context读前及事务内owner检查仍在，read-onlyworkflow handler先project owner；native channel无scope绕过、trusted_ui仍需真实session/CSRF。没有再发现此批已注册artifact/context的具体跨owner读写路径。执行producer仍未挂，safe-control内部能力不应据此直接开放为无owner检查的HTTP生产入口。

本轮源码C-R1..4均已定向修正，新增C-R5待MAIN处理；未冻结预审仍NEEDS_WORK，不签整A。


## C-R5修正及job.read边界复核（R8未冻结）

输入 c-r5-fix-input-hashes.json，实际MAIN HEAD仍4b683a1加dirty。本次读取四文件hash：CreativeService `b896b99e4b0e5f293d8d95c282aad4fa23614a5d252c933f0a4f46bff8f6fa8c`；authority `63abf1659a84b73fe68e4b61abffc067678ac160a88a6bafd18c2e5859f94ca4`；CreationApplication `f71812c1219c6d1ef63fb28e5a4ecd66e7b03b2a18d26e0b54826a4f8bc0f91b`；integration test `006dd039d449979d4cfefb4728003247ff61ab2317a32acf3423c848d6f8df2f`。本人未跑测试、未改MAIN；R8 exec64719是MAIN正在执行，不能记本审查独立通过。

**C-R5 SOURCE_ADDRESSED。** 新可选同步contentAuthority在CreativeService relay事务内，紧随assertIntakeOwner、先于recallIdempotency；生产CreationApplication必注入authority.assertContent。nullable project_id===null保留合法preproject；非null先核同owner已提交created project，再核creation.request.intake_id与输入一致。authority调用creation共享的同SQLite连接，未在检查/写之间await。matching project历史幂等仍回原响应，foreign/missing/mismatched工程不能借原key跳access。Intake版本仍由旧closure验证，不误要求输入版本必须等于工程最初创建版本，从而保留后续内容修订。

新增HTTP testcase覆盖unknown project404且无新decision、other principal自有Intake标到本owner工程404、sameowner其他Intake标到该工程409、匹配成功并原响应重放、other principal合法null preproject成功。它们都在真实Host/SQLite路径，而非只测MemoryRepo。MAIN报告main-relay-scope-negative真正复现unknown-project=200；首次main-relay-scope-before用了非法冒号ID导致400，不是旧行为复现，两者应分别保留，不能合并当同一证据。本段只记录MAIN说明及当前测试源码，未独立运行这两个负向。

**job.read权限/producer SOURCE_REVIEWED。** 当前先creation.ownsProject，而不是assertOwner(origin required)，故原creator预约尚无origin时仍可poll；跨owner先404。之后实际Job必须存在且project_id匹配URL，再确认该Job由creator producer管理，否则503，既不返回其他project任务，也不隐藏未知producer或将其误报409。最后creator receipt仍核project一致。failed/cancelled创建诊断允许读取，没有把source是否存在当访问权限依据。

当前C-R1..5已全部针对源码修正，未发现本轮C-R5/job.read修法的新具体阻断。状态为 **SOURCE_REVIEW_COMPLETE / FROZEN_INDEPENDENT_VERIFICATION_PENDING**；不再把旧C-R5当当前未修问题。此前所有初始问题/hash/负向仍保留。待R8实际终态及新冻结SHA后，只按授权范围独立验证，不提前签A03/整A。


## 冻结791fd1d独立结论

限定Creative/Context链 **PASS**。输入`791fd1dfb8958889c101715a68cc628898ed650c`，前后MAIN clean；本人独立18/18、tsc0、Python10 golden0，exec79293/17953均terminal exit0，无残留并释放资源。12source+49artifact与冻结tree/worktree的bytes/hash61/61一致。C-R1..5已按真实SQL/HTTP及明确组件边界关闭本链问题；详细报告和原始日志见 [../frozen-791fd1d/REVIEW.md](../frozen-791fd1d/REVIEW.md)。不签完整A03/A、生产Run、原生UI、影片/双导出或人验。
