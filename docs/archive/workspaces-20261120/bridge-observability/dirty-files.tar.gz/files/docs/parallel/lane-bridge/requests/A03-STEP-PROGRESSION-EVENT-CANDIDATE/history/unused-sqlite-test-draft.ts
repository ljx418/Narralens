import {it,expect} from 'vitest';
import {RevisionStore} from '../../../src/host/projects/revision-store.js';
import {PersistentJobStore} from '../../../src/host/persistent-job-store.js';
import {ProductSqliteRepository} from '../../../src/host/agent-driven/product-sqlite-repository.js';
import {FixedWorkflowService,type RecordStepAttemptInput} from '../../../src/host/creative/fixed-workflow-service.js';
import {CreativeService} from '../../../src/host/creative/creative-service.js';
import {creativeInputClosure} from '../../../src/host/creative/creative-closure.js';
import {canonicalDigest} from '../../../src/host/creative/digest.js';
import type {ProductRepository} from '../../../src/host/creative/product-repository.js';
import {BRIEF,meta,NOW_EPOCH_SECONDS,NOW_ISO,RELAY_CALLER,TRUSTED_CALLER,TestFactPort,TestAdoptionAuthority} from '../product/support/fixtures.js';

/** Real original workflow methods + real SQLite/FKs/events. Facts/confirmation are
 * explicit component TEST ports; NOT production project/rights/Run/human proof. */
async function fixture(){
 const revisions=new RevisionStore();
 try{
  revisions.ensureProject('project-1',3);
  const repo=new ProductSqliteRepository(revisions),facts=new TestFactPort(),adoption=new TestAdoptionAuthority();
  let clock=NOW_EPOCH_SECONDS;const now=()=>clock;
  const creative=new CreativeService({repository:repo,now});
  const service=new FixedWorkflowService({repository:repo,facts,adoption,now});
  const intake=await creative.putIntake({meta:meta('event-intake'),intake_id:null,base_version:0,brief:BRIEF},RELAY_CALLER);
  const briefDigest=canonicalDigest(BRIEF),style={id:'brief-carrier',version:1,sha256:briefDigest};
  await repo.transaction(tx=>{
   tx.put('artifact_version',{project_id:'project-1',artifact_id:style.id,version:1},{project_id:'project-1',artifact_id:style.id,version:1,kind:'brief',schema_version:1,input_digest:briefDigest,content_digest:briefDigest,content_json:BRIEF,input_refs_json:[],created_at:NOW_ISO});
   tx.compareAndSet('artifact_head',{project_id:'project-1',artifact_id:style.id},0,{project_id:'project-1',artifact_id:style.id,draft_version:1});
  });
  const storyboard=await creative.putArtifact({meta:meta('event-storyboard'),project_id:'project-1',artifact_id:null,base_version:0,input_digest:'e'.repeat(64),input_refs:[],content:{kind:'storyboard',fps:30,shots:[{shot_id:'shot-1',paragraph_id:'p-1',asset_id:null,duration_frames:90,caption:'',concept_text:'component event fixture'}]}},RELAY_CALLER);
  const closure=await repo.transaction(tx=>canonicalDigest(creativeInputClosure(tx,intake.intake_id,intake.version)));
  const decision=await creative.relayContentDecision({meta:meta('event-content'),project_id:null,intake_id:intake.intake_id,intake_version:intake.version,input_digest:closure,request_id:'event-request',choice:'accept_content',source:'driver_relay',source_message_ref:'component-message'},RELAY_CALLER);
  const run=await service.prepareRun({meta:meta('event-run'),project_id:'project-1',intake_decision_id:decision.decision_id,template_id:'local-short-film',template_version:1,input_refs:[storyboard.ref],input_digest:closure,style_ref:style,content_type:'short_film'},RELAY_CALLER);
  const grant=await service.authorizeRun({meta:meta('event-grant'),project_id:'project-1',run_id:run.run_id,scope_digest:run.scope_digest,choice:'authorize'},TRUSTED_CALLER);
  const jobs=new PersistentJobStore(revisions),job=jobs.create({projectId:'project-1',kind:'snapshot_publish',payload:{run_id:run.run_id,step_id:'sample',attempt:1},maxAttempts:1},new Date(clock*1000));
  const input:RecordStepAttemptInput={project_id:'project-1',run_id:run.run_id,plan_version:1,step_id:'sample',attempt:1,grant_id:grant.authorization_id,input_digest:closure,state:'pending',job_id:job.job_id,input_refs:[storyboard.ref],observed_at:NOW_ISO};
  const count=(table:string)=>revisions.compose(db=>Number(db.prepare('SELECT count(*) AS n FROM '+table).get()?.n));
  const snapshot=()=>repo.transaction(tx=>({run:tx.get('run',{project_id:'project-1',run_id:run.run_id}),attempt:tx.get('step_attempt',{project_id:'project-1',run_id:run.run_id,plan_version:1,step_id:'sample',attempt:1}),outbox:count('outbox'),events:count('cp_a0_event'),job:revisions.readJob(job.job_id)}));
  const tick=()=>{clock++;return new Date(clock*1000).toISOString();};
  return {revisions,repo,facts,adoption,service,jobs,job,input,run,now,tick,snapshot,count,close:()=>revisions.close()};
 }catch(error){revisions.close();throw error;}
}

it('original workflow method pending→running advances the same checkpoint and one outbox/cp event per update',async()=>{
 const f=await fixture();try{
  expect(f.revisions.compose(db=>db.prepare('PRAGMA foreign_keys').get()?.foreign_keys)).toBe(1);
  const before=await f.snapshot();
  await f.service.recordStepAttempt(f.input,TRUSTED_CALLER);
  const pending=await f.snapshot();expect(pending.attempt).toMatchObject({state:'pending',job_id:f.job.job_id});expect(pending.outbox).toBe(before.outbox+1);expect(pending.events).toBe(before.events+1);
  expect(pending.run!.checkpoint_json.workflow_revision).toBe(before.run!.checkpoint_json.workflow_revision+1);
  const at=f.tick();expect(f.jobs.acquireLease(f.job.job_id,{owner:'event-worker',now:new Date(at)})).toBe(true);
  await f.service.recordStepAttempt({...f.input,state:'running',observed_at:at},TRUSTED_CALLER);
  const running=await f.snapshot();expect(running.attempt).toMatchObject({state:'running',job_id:f.job.job_id,updated_at:at});
  expect(running.run!.checkpoint_json.attempts.find(a=>a.step_id==='sample'&&a.attempt===1)).toMatchObject({state:'running',job_id:f.job.job_id});
  expect(running.run!.checkpoint_json.workflow_revision).toBe(pending.run!.checkpoint_json.workflow_revision+1);expect(running.outbox).toBe(pending.outbox+1);expect(running.events).toBe(pending.events+1);expect(running.job?.state).toBe('running');
  const mirror=f.revisions.compose(db=>db.prepare("SELECT o.payload_json FROM outbox o JOIN cp_a0_event e ON e.event_id=o.event_id WHERE o.topic='workflow.run.state_changed' AND e.source='worker' ORDER BY o.event_id DESC LIMIT 1").get());
  expect(JSON.parse(String(mirror!.payload_json))).toMatchObject({topic:'workflow.run.state_changed',scope:{kind:'run',project_id:'project-1',run_id:f.run.run_id,run_scope_digest:f.run.scope_digest,plan_version:1},entity:{type:'task',id:'sample',version:1,state:'running'},attempt:1,input_digest:f.input.input_digest,payload:{step_id:'sample',attempt:1,state:'running',job_id:f.job.job_id}});
 }finally{f.close();}
});
it('a real mirrored-event FK failure rolls back prior attempt/checkpoint/outbox writes and leaves the original method usable',async()=>{
 const f=await fixture();try{
  await f.service.recordStepAttempt(f.input,TRUSTED_CALLER);
  const at=f.tick();expect(f.jobs.acquireLease(f.job.job_id,{owner:'event-worker',now:new Date(at)})).toBe(true);
  const before=await f.snapshot();
  /** Deliberately corrupt only the emitted fixture scope; original service writes and
   * real adapter/outbox/FK remain unchanged. No CP DDL, fake event store or copied service logic. */
  const failingRepo:ProductRepository={transaction:work=>f.repo.transaction(tx=>work({...tx,emit:event=>{
   if(event.topic==='workflow.run.state_changed'&&event.scope.kind==='run')return tx.emit({...event,scope:{...event.scope,run_id:'missing-run-fixture'}});
   return tx.emit(event);
  }}))};
  const failing=new FixedWorkflowService({repository:failingRepo,facts:f.facts,adoption:f.adoption,now:f.now});
  const input={...f.input,state:'running' as const,observed_at:at};
  await expect(failing.recordStepAttempt(input,TRUSTED_CALLER)).rejects.toThrow(/FOREIGN KEY/);
  expect(await f.snapshot()).toEqual(before);
  await f.service.recordStepAttempt(input,TRUSTED_CALLER);
  const after=await f.snapshot();expect(after.attempt?.state).toBe('running');expect(after.outbox).toBe(before.outbox+1);expect(after.events).toBe(before.events+1);expect(after.run!.checkpoint_json.workflow_revision).toBe(before.run!.checkpoint_json.workflow_revision+1);
 }finally{f.close();}
});
