# Execute ONLY after final validation evidence is captured and all own processes stopped.
from pathlib import Path
import json,os,stat,shutil
out=Path(__file__).resolve().parent
inp=json.loads((out/'input.json').read_text());root=Path(inp['temporary_root'])
if root.parent!=Path('/tmp') or not root.name.startswith('narralens-bridge-task-7b48-'):raise SystemExit('REFUSE_WRONG_ROOT')
s=root.lstat()
if stat.S_ISLNK(s.st_mode) or not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or s.st_mode&0o077:raise SystemExit('REFUSE_ROOT_IDENTITY')
if json.loads((root/'.bridge-task-owner.json').read_text())!=inp['owner_marker']:raise SystemExit('REFUSE_OWNER_MARKER')
shutil.rmtree(root)
(out/'cleanup-result.json').write_text(json.dumps({'root':str(root),'removed':not root.exists(),'scope':'only own exact temp root with matching owner nonce'},indent=2)+'\n')
