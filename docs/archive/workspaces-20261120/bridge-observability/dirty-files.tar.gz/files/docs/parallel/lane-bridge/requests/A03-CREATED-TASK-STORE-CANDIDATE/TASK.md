Implement private source candidate described in immutable DESIGN-v1.md. One writer: Codex BRIDGE. Production MAIN excluded. Preparation/source only; no tests/build/Host/browser/media authorized.
