# 当前执行令：A-R1-PRODUCT RELEASED（2026-11-11）

本节覆盖下方全部历史NOT_RELEASED/凭据等待/19文件/旧base描述，历史原文保留不修改。按本地MAIN_START.md、ReleaseAssignment.json及committed implementation-20261111/AUTHORIZATION_INTERPRETATION.md执行：现有Claude CLI调用已获用户授权，实际凭据处置UNKNOWN，不要求再次审批，不读改配置/凭据、不切模型供应商。

base/fullHEAD `84deba07927fa59b45a24039b4740a2f9d3fd430`；R0源码freeze `9f583239714835a89332fcae9363aa39d887821d`；contract `ca5b67a8285b130c79055317c6202f73cfbb99c8`。实际cwd `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT`。父Codex `term_dbe899889c960daeaba8b5f3ba7fe6e2`，task `task_9e9e39498505`，dispatch `ctx_3481af515722`；MAIN `term_a731c232-35c7-4f55-a75d-9b2beeade398`。启动前dirty仅本票私有文档，tracked diff为空；R0→HEAD源码/tests/contracts/tools/package/lock差异为空。CR摘要和registry摘要现场匹配Assignment。

当前写权交接：Codex完成本次文档准备后启动一个keep-open Claude；真实launch回执后Claude为本lane唯一文件/index/运行根writer，Codex只读。子Claude须在HANDOFF记实际注入的子Task/Dispatch/handle与父关系、会话自报模型或UNKNOWN、命令与证据；不要读取用户配置来证明MiniMax。子任务不得再启动任何helper。当前没有运行的本票实现进程，实际子身份由launch回执确定，不能抄历史ID。

精确23产品路径如下，全局127 owner路径、首批55 BRIDGE/23 PRODUCT/12 MEDIA。可写本票文档/logs/evidence；不改Assignment/MAIN_START/封存包/公共合同/vendor/其他owner。无全目录git add，不push、不合主干。
- `src/app/agent-workbench-client.ts`
- `src/app/m5/GatewayApiClient.ts`
- `src/app/m5/M5Panel.tsx`
- `src/app/m5/SelectionCoordinator.ts`
- `src/app/main.tsx`
- `src/app/observation/CreativeReviewPanel.tsx`
- `src/app/observation/LocalAssetRegistrationPanel.tsx`
- `src/app/observation/NativeSyncIndicator.tsx`
- `src/app/observation/WorkflowTopBar.tsx`
- `src/app/observation/content-views.tsx`
- `src/app/observation/index.ts`
- `src/app/observation/observation.css`
- `src/app/owned-project-client.ts`
- `src/app/system/SystemControlPanel.tsx`
- `src/app/system/index.ts`
- `src/app/system/system.css`
- `src/host/m5/controlled-studio-access.ts`
- `src/host/m5/controlled-studio-browser.ts`
- `src/host/m5/openfilm-studio-gateway.ts`
- `tests/agent-driven/integration/created-native-ui-transport.test.ts`
- `tests/agent-driven/integration/created-workbench-review.test.ts`
- `tests/agent-driven/product/local-asset-registration.test.tsx`
- `tests/agent-driven/product/observation-ui.test.tsx`

先读committed CR-R1-001 sections1–8、gateway-ui.registry.json、interface-decision.json；I1/I2/P-CR-01已闭合，不再设计审计。独立UI delegate只从真实Host trusted_ui铸造，native-only不授信，31+5+2精确计数；native.reopen空input及review.part.describe精确input，真实probe fps/frame_count/audio samples绑定receipt与descriptor；校验descriptor/ETag/hash/bytes后才预览，原单槽/单clock模式，无hydration/expected/pin实现。

实施顺序：先在controlled-studio-access.ts导出兼容旧native的NativeStudioUiGrantV1/可选ui最小类型接缝，按CR锁定invoke/openReviewMedia所需语义，最窄tsc并将该文件显式提交早期类型candidate，报告父Codex完整SHA及字段/命令日志。随后连续实现独立UI session/closed Gateway aliases/browser proof与原M5 Bar/System/review/素材/预览消费者；无额外小模块人验。不重复定义MEDIA的receipt/reader协议；MEDIA assembly-ports类型候选由MAIN集成，缺export时报告明确需要、继续独立UI/认证工作，不塞生产替身。

轻量typecheck/纯单元可用独立离线依赖执行并留本票日志：corepack pnpm exec tsc --noEmit；corepack pnpm test tests/agent-driven/product/observation-ui.test.tsx tests/agent-driven/product/local-asset-registration.test.tsx --maxWorkers=1 --minWorkers=1（新文件存在后）。任何监听Host/真实媒体/ffmpeg/Chromium/build/full检查先经父Codex向MAIN申请单槽，未获槽不执行。transport集成测试涉及Host时同样预约。当前无重型reservation。不安装/联网/J盘/付费provider/素材外传；Headless静音、不抢焦点。

逐case沿历史TASK和审定ACCEPTANCE的本票子集；记录原失败、NOT_RUN、实际argv/cwd/起止/exit/log SHA、变更路径/完整SHA/进程清理。模拟仅单元证据，缺生产者503/unknown，不声称A可用或R2/R3完成。完成后仅显式add自身已释放路径冻结候选，输出CLAUDE_RESULT.md及HANDOFF证据；Codex后续分时读代码/重跑验收，非独立产品/人验。

遇429立即保全dirty/失败并停止原调用与所有子进程、向父报告可核查停止证据；MAIN已预授权Codex核实后接管，不需重复审批，Claude不得自动抢回。>2阶段返工交MAIN根因。普通问题自行修复；未知外部写结果先同key对账。无B。

---

# A-R1-PRODUCT Claude handoff — NOT_RELEASED / NOT_STARTED

本文件仅准备，不是启动指令。尚未确认凭据事件处置，不得调用Claude。先读取同目录TASK.md、HANDOFF.md与MAIN最新ReleaseAssignment；状态必须RELEASED且MAIN确认唯一writer移交后才执行。

实际cwd `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT`；base `9f583239714835a89332fcae9363aa39d887821d`；contract `ca5b67a8285b130c79055317c6202f73cfbb99c8`。本票19文件（14已有+5拟新增）精确列表/逐case/命令在TASK，不允许由下方完整A提示扩展。当前只准备3文档；Claude从未在本任务启动。

下方原文完整保留，SHA256 `5ec473385356d5e6dc49ec9c45a4cf446c8633cba7d98ee202515dbb2f3d03e0`。原文旧MAIN overlay及全A主线是历史/总路线；现场完整base及此R1 scope优先：只Bar/System/review/local asset消费者，native gateway/pin/Host Ack/expected/013/015构建、完整采用/导出/QC不在票内。I1可信transport与I2原player prepared preview call由MAIN明确或明确暂交blocked消费者；不要自行发明跨origin授权或播放器。

实现前复核三份文档与ReleaseAssignment。依赖未提供返回真实unknown/blocked，禁止test mock接生产。TASK中的旧UI保持、DTO、错误、同key恢复、测试证据与writer条件均适用。模型仅会话自报/UNKNOWN，禁止用户配置/凭据/env读取，不启动助手。不自动索引/commit/换分支；MAIN另行给精确冻结动作后执行。

---

## 已审定完整实施提示原文（逐字保留）

# PRODUCT ClaudeCode（MiniMax）A阶段实施提示词

本提示词是下一轮正式实施输入，**本轮只读检查不执行它**。先核MAIN实际发放的IMPLEMENTATION_RELEASE与此lane ReleaseAssignment；没有实施授权或status不是RELEASED，仅向所属Codex报告NOT_RELEASED，不写产品代码、不运行测试或服务。本提示词/文档认可本身不产生release。

## 阅读顺序与保全

canonical /mnt/c/workspace/videoworkline/Narralens（Windows C:\workSpace\videoWorkLine\Narralens）；包docs/execution/A/relaunch-20261111。先读canonical AGENTS.md、docs/AGENT_MEMORY.md、docs/agent-driven-v1/11_AGENT_DELIVERY_PROCESS.md，再本包00_READ_FIRST、02_MAIN_CONTRACT_AND_DECISIONS（D01-D15全篇，末节覆盖旧草案）、03_OWNERSHIP_AND_DEPENDENCIES.json、04_COORDINATED_EXECUTION_PLAN、05_MAIN_ACCEPTANCE_AND_REVIEW、06_MAIN_REVIEW_AND_START_GATE，然后product/DESIGN、ACCEPTANCE、TASK以及CLAUDE_READINESS的原发现/后续关闭记录。

已观察MAIN HEAD 838ba5f2c8500f0103f56dbe51264ea9f70086fc + baseline-observed.json中25文件overlay；原合同commit ca5b67a8285b130c79055317c6202f73cfbb99c8，文档commit f0c4f4f34fb1b81cf1ea0e0af2fd22a9eab38450。共同新实施commit应由R0实际生成，再由MAIN填写；不要捏造SHA或自行改base。按release.directory执行git rev-parse HEAD/status，核完整SHA、contract manifest和overlay/候选hash；若不是所述实际版本先报领域Codex，不reset/stash/rebase/cherry-pick覆盖。研究lane不是最新MAIN来源，保持所有未提交候选。

## 职责与写入范围

你是具体编码/接线/开发子阶段自验证节点；所属PRODUCT Codex负责详细设计、文档和领域复核，MAIN负责总合同/跨领域协调与大阶段验收。唯一允许产品文件是MAIN实际ReleaseAssignment与03表中分给product-Claude且本票已释放的**交集**。禁止默认全目录授权；未列文件或需要改冻结合同，先报Codex提出精确请求。共用文件有唯一writer，其他窗口只读；不用全目录git add，不自动push/合主干。

保持同Host/RevisionStore连接/原Job与lease/step_attempt/Coordinator/project_transaction、原生七方法EnginePort、strict409、一个引擎绑定与同Studio timeline/selection/clock。不能新项目/第二DB/第二队列或写源旁路。新created_*事实表不是第二状态机，不能污染精确cp_a0_* namespace。31原路由/80defs/冻结SQL不暗改；附属5HTTP+1resource单独schema/注册/版本计数。

## 本领域实施主线（P-A1/P-A2/P-A3）

1. 在原工作台增量挂载WorkflowTopBar（顶部可折叠横向阶段，节点弹窗任务细节）、SystemControlPanel（非模态aside，无backdrop/focus trap，仍可剪辑）及必要Review/素材入口。保留已有OpenFilm/M5控件、单selection/clock；不新建聊天页/时间轴/编排平台。
2. P-A1 Agent内容定义→工作台可信Run授权/素材选择登记→真实preview+narration+subtitles+shot_summary+rights_quality合包审阅。用户在配置根候选中选择视频/人声、声明许可与来源；Host处理hash/登记，Agent inventory读同一ID，不让人复制ID/JSON。按已冻结附属schema/registry消费，未知或未就绪明确blocked。
3. P-A2 一次accept_and_adopt→Decision/Approval已记录→采用pending→实际commit→真实NativeAck，四事实分开。纯accept不提交，响应ReviewDecision不是Applied。最终QC也是同一工作台真实决定，依据RunGate.kind=qc和Host私有绑定显示成片与质量报告，不把普通chapter_pack、已accepted章节或技术QC自动当人类接受。
4. 复用requests013/015固定候选，隔离副本构建并验证pin，不写vendor。Host expected独立源事实与真实observed session/generation/view/document_epoch/hydration_epoch/所有parts/selection绑定，只有settings/markers computed不代表captions/style或整个工程loaded；dirty/unsupported/failed/断线不假绿。
5. P-A3 在原编辑区改单镜，调用受控影响/批准/采用路径；正式导出展示真实snapshot/QC/manifest/download，preview不冒充Delivery。关服重开重新绑定会话/原生观察，旧Ack作废；两次正式输出变化区与不变区对应。

你独占的native Host模块仅按03和release列出的文件实施，通过已审port对接BRIDGE共享装配，不改其server/DDL/Coordinator。验收关注真实浏览器路径、键盘/焦点/线性创作流程、p95事件显示、旧控件不回归；组件mock只算内部，实际E2E要真Host/Studio/媒体。

## 连续开发、自验证和证据

按领域ACCEPTANCE逐case完成；先最窄真实路径再负向矩阵，不为每个函数停下来问人。既有通过模块复用，无确定缺陷不重写。纯fixture只证明组件，真实Host/CLI/媒体/浏览器分别标证据；无测试替身注入生产。不得为过测放松guard/超时/合同，未知异常不一律归因ENOMEM；保留第一失败与修复后证据，重要负向必须能在旧违规实现上打红。

工具链先在实际worktree用corepack pnpm --version确认10.33.0、node>=22.15.0，只读元信息可查；禁止自行安装/下载、读取用户配置/凭据或全量env。模型只采信会话自报，UNKNOWN也可；禁止为验证供应商读取~/.claude、~/.codex、.env或密钥。凭据事件见audit/CREDENTIAL_EVENT，相关人类处置由MAIN负责。

以下是**实施释放后**才执行的已存在入口（命令cwd=release.directory）；具体新case文件在创建后纳入同一test过滤，不冒称现在已有：
- corepack pnpm exec tsc --noEmit
- corepack pnpm test tests/agent-driven/product --maxWorkers=1 --minWorkers=1
- corepack pnpm test:contracts
- corepack pnpm build（需要MAIN重型资源预约）

全量corepack pnpm check、多Host/ffmpeg/Headless/GPU大fixture由MAIN全机单槽统一预约，不能三窗口各跑一套。自动化Headless、静音、无弹窗/焦点抢占；每个Host/profile/DB/var/staging独立并精确清理，禁止kill所有浏览器/服务。不读J盘/不付费/不新外传或切供应商，除非当前任务明确授权。

交付记录ticket、base/contract/实现完整SHA、dirty manifest/修改文件与来源、真实命令cwd/开始结束/exit/日志和SHA256、逐case PASS/FAIL/NOT_RUN、恢复/回退/进程清理/剩余依赖。git只显式add本票文件，冻结后交所属Codex只读复核。子阶段自测不能签独立或人验；实际Orca task/from以注入preamble为准，不复用旧任务ID。

429：记录错误，停止写入并把dirty/在途命令交Codex；Codex核实旧调用及子进程停止后才接管。超过两次返工由MAIN接管共同根因，不机械反复重试。服务422/529等按真实原因保留，不改模型/配置逃避。未知写结果读原idempotency/job/receipt，不能换key盲重发。

停止在本票实际出门条件或真实越权/高风险阻塞；将结果回所属Codex，不进入未释放票据。A末由MAIN统一全量/独立审查/中文HTML/人工入口，不自行宣称A/V1通过，不进入B。
