# R2 implementation handoff — DO NOT EXECUTE BEFORE EXACT RELEASE

This is prepared text, not a launched Claude task. Latest ticket is docs-only. MAIN's future RELEASED assignment with actual directory/base/contract/paths and Codex writer handoff is required; no repeated credential approval is invented. Existing configured CLI is authorized by the user when released; credential disposition remains UNKNOWN and configuration/credentials/env must not be read.

Read TASK.md and HANDOFF.md first. This R2 slice is P-A2 only, using integrated baseline de086f32c48c44fb72d0212ef80365f1c786408c or MAIN's explicitly supplied descendant, not local ed44. Keep the complete base prompt below as policy/context; its old pending statements and older base observations are history, while this exact docs-only limit is current. Do not implement P-A1 again or advance P-A3/R3/R4/B merely because the full base prompt mentions them.

After release: verify exact base/status/input hashes and 15-path proposed list against actual assignment; resolve I1–I4 with MAIN's concrete ports/pin before dependent code, without redesign. Implement review decision vs commit vs loaded separation using existing routes, then real observation/independent expected/Host Ack, current-package preview and reopen; preserve static browser validators and R1 editor/Bar/system. Test actual failure/recovery cases mapped in TASK, report raw failures and NOT_RUN dependencies, never hardcode any of four missing capability producers or synthesize Ack. Write only exact released files; no shared source or pin change by implication. Keep one writer and visible Orca terminal, log real new child IDs, reserve heavy slot through parent, freeze implementation SHA and return evidence to Codex. No helpers unless MAIN explicitly asks.

## MAIN reconciliation follow-up (binding preparation input)

Before implementation read canonical R2/MAIN_RECONCILIATION.md and current-code-map.json, and TASK's precise native interface matrix. Production native observation/expected/Ack files are absent at de086; reuse pinned 013/015 source artifacts without treating settings/markers computed as full-source/captions/style proof. Validate real authenticated session/generation/view/document/hydration epochs internally before emitting the unchanged frozen Ack shape; never fabricate observed values from Host expected. MAIN schedules real R3 phase ports/core foundations early in parallel, but four-capability Run admission remains strict and no fakeRun fixture is production evidence. Preserve static public validators/CSP, exact DTOs, no app-to-Host imports, and current R1 cold UI behavior. No launch or writes until exact release and unique-writer handoff; I1–I4 are concrete producer/pin seams, not a request for broad redesign.

## Full reviewed implementation-prompts/product.md base (verbatim)

# PRODUCT ClaudeCode（MiniMax）A阶段实施提示词

本提示词是下一轮正式实施输入，**本轮只读检查不执行它**。先核MAIN实际发放的IMPLEMENTATION_RELEASE与此lane ReleaseAssignment；没有实施授权或status不是RELEASED，仅向所属Codex报告NOT_RELEASED，不写产品代码、不运行测试或服务。本提示词/文档认可本身不产生release。

## 阅读顺序与保全

canonical /mnt/c/workspace/videoworkline/Narralens（Windows C:\workSpace\videoWorkLine\Narralens）；包docs/execution/A/relaunch-20261111。先读canonical AGENTS.md、docs/AGENT_MEMORY.md、docs/agent-driven-v1/11_AGENT_DELIVERY_PROCESS.md，再本包00_READ_FIRST、02_MAIN_CONTRACT_AND_DECISIONS（D01-D15全篇，末节覆盖旧草案）、03_OWNERSHIP_AND_DEPENDENCIES.json、04_COORDINATED_EXECUTION_PLAN、05_MAIN_ACCEPTANCE_AND_REVIEW、06_MAIN_REVIEW_AND_START_GATE，然后product/DESIGN、ACCEPTANCE、TASK以及CLAUDE_READINESS的原发现/后续关闭记录。

已观察MAIN HEAD 838ba5f2c8500f0103f56dbe51264ea9f70086fc + baseline-observed.json中25文件overlay；原合同commit ca5b67a8285b130c79055317c6202f73cfbb99c8，文档commit f0c4f4f34fb1b81cf1ea0e0af2fd22a9eab38450。共同新实施commit应由R0实际生成，再由MAIN填写；不要捏造SHA或自行改base。按release.directory执行git rev-parse HEAD/status，核完整SHA、contract manifest和overlay/候选hash；若不是所述实际版本先报领域Codex，不reset/stash/rebase/cherry-pick覆盖。研究lane不是最新MAIN来源，保持所有未提交候选。

## 职责与写入范围

你是具体编码/接线/开发子阶段自验证节点；所属PRODUCT Codex负责详细设计、文档和领域复核，MAIN负责总合同/跨领域协调与大阶段验收。唯一允许产品文件是MAIN实际ReleaseAssignment与03表中分给product-Claude且本票已释放的**交集**。禁止默认全目录授权；未列文件或需要改冻结合同，先报Codex提出精确请求。共用文件有唯一writer，其他窗口只读；不用全目录git add，不自动push/合主干。

保持同Host/RevisionStore连接/原Job与lease/step_attempt/Coordinator/project_transaction、原生七方法EnginePort、strict409、一个引擎绑定与同Studio timeline/selection/clock。不能新项目/第二DB/第二队列或写源旁路。新created_*事实表不是第二状态机，不能污染精确cp_a0_* namespace。31原路由/80defs/冻结SQL不暗改；附属5HTTP+1resource单独schema/注册/版本计数。

## 本领域实施主线（P-A1/P-A2/P-A3）

1. 在原工作台增量挂载WorkflowTopBar（顶部可折叠横向阶段，节点弹窗任务细节）、SystemControlPanel（非模态aside，无backdrop/focus trap，仍可剪辑）及必要Review/素材入口。保留已有OpenFilm/M5控件、单selection/clock；不新建聊天页/时间轴/编排平台。
2. P-A1 Agent内容定义→工作台可信Run授权/素材选择登记→真实preview+narration+subtitles+shot_summary+rights_quality合包审阅。用户在配置根候选中选择视频/人声、声明许可与来源；Host处理hash/登记，Agent inventory读同一ID，不让人复制ID/JSON。按已冻结附属schema/registry消费，未知或未就绪明确blocked。
3. P-A2 一次accept_and_adopt→Decision/Approval已记录→采用pending→实际commit→真实NativeAck，四事实分开。纯accept不提交，响应ReviewDecision不是Applied。最终QC也是同一工作台真实决定，依据RunGate.kind=qc和Host私有绑定显示成片与质量报告，不把普通chapter_pack、已accepted章节或技术QC自动当人类接受。
4. 复用requests013/015固定候选，隔离副本构建并验证pin，不写vendor。Host expected独立源事实与真实observed session/generation/view/document_epoch/hydration_epoch/所有parts/selection绑定，只有settings/markers computed不代表captions/style或整个工程loaded；dirty/unsupported/failed/断线不假绿。
5. P-A3 在原编辑区改单镜，调用受控影响/批准/采用路径；正式导出展示真实snapshot/QC/manifest/download，preview不冒充Delivery。关服重开重新绑定会话/原生观察，旧Ack作废；两次正式输出变化区与不变区对应。

你独占的native Host模块仅按03和release列出的文件实施，通过已审port对接BRIDGE共享装配，不改其server/DDL/Coordinator。验收关注真实浏览器路径、键盘/焦点/线性创作流程、p95事件显示、旧控件不回归；组件mock只算内部，实际E2E要真Host/Studio/媒体。

## 连续开发、自验证和证据

按领域ACCEPTANCE逐case完成；先最窄真实路径再负向矩阵，不为每个函数停下来问人。既有通过模块复用，无确定缺陷不重写。纯fixture只证明组件，真实Host/CLI/媒体/浏览器分别标证据；无测试替身注入生产。不得为过测放松guard/超时/合同，未知异常不一律归因ENOMEM；保留第一失败与修复后证据，重要负向必须能在旧违规实现上打红。

工具链先在实际worktree用corepack pnpm --version确认10.33.0、node>=22.15.0，只读元信息可查；禁止自行安装/下载、读取用户配置/凭据或全量env。模型只采信会话自报，UNKNOWN也可；禁止为验证供应商读取~/.claude、~/.codex、.env或密钥。凭据事件见audit/CREDENTIAL_EVENT，相关人类处置由MAIN负责。

以下是**实施释放后**才执行的已存在入口（命令cwd=release.directory）；具体新case文件在创建后纳入同一test过滤，不冒称现在已有：
- corepack pnpm exec tsc --noEmit
- corepack pnpm test tests/agent-driven/product --maxWorkers=1 --minWorkers=1
- corepack pnpm test:contracts
- corepack pnpm build（需要MAIN重型资源预约）

全量corepack pnpm check、多Host/ffmpeg/Headless/GPU大fixture由MAIN全机单槽统一预约，不能三窗口各跑一套。自动化Headless、静音、无弹窗/焦点抢占；每个Host/profile/DB/var/staging独立并精确清理，禁止kill所有浏览器/服务。不读J盘/不付费/不新外传或切供应商，除非当前任务明确授权。

交付记录ticket、base/contract/实现完整SHA、dirty manifest/修改文件与来源、真实命令cwd/开始结束/exit/日志和SHA256、逐case PASS/FAIL/NOT_RUN、恢复/回退/进程清理/剩余依赖。git只显式add本票文件，冻结后交所属Codex只读复核。子阶段自测不能签独立或人验；实际Orca task/from以注入preamble为准，不复用旧任务ID。

429：记录错误，停止写入并把dirty/在途命令交Codex；Codex核实旧调用及子进程停止后才接管。超过两次返工由MAIN接管共同根因，不机械反复重试。服务422/529等按真实原因保留，不改模型/配置逃避。未知写结果读原idempotency/job/receipt，不能换key盲重发。

停止在本票实际出门条件或真实越权/高风险阻塞；将结果回所属Codex，不进入未释放票据。A末由MAIN统一全量/独立审查/中文HTML/人工入口，不自行宣称A/V1通过，不进入B。


# EFFECTIVE MAIN R2 IMPLEMENTATION RELEASE — supersedes earlier preparation status

Actual release received for task_a80e19dd8567 / ctx_28c97d42b1c4 / parent term_a12b41198786723b7ec686bacd39039f. RELEASED assignment is local ReleaseAssignment.json, exact SHA256 03ac04a80e1e3e1ec0a8d283ab7f8fe111befbb9b6d6d316229de82a6a2889fb; INTERFACE_LOCK.md SHA256 e25140ff5e71272f042387804fb75b751cf576621eb99c381dc93c221c529b17. Both match immutable MAIN commit dd2be1f08e65305dac6d0e4ecb05a03e1875e5b2. Actual implementation base39201d932cd10e0ce60b023bdde2f233dfb009e5, branch agent-driven/a-r1-product, source-equivalent common0c1b73cbe384938083482355aaba8eb548c7971b/de086. All earlier docs-only limits, proposed15 count and unresolved I1–I4 are historical and superseded by this exact31-path release and L01–L08; no new user approval is needed.

Prelaunch evidence R2_RELEASE_PREFLIGHT.json records source/index checks, all33 protected alignment files unchanged, ticket hashes before this append, node22.22.1/pnpm10.33.0, settled/retained old child and no old Claude descendants/active owned runtime commands observed. Keep old retained CLI idle; launch a fresh visible R2 task since worker terminal reuse is not supported by this worker-start context, never resume R1 task. Parent owns documentation now and becomes read-only during Claude source/index/runtime ownership. Child records its actual launch receipt in HANDOFF once received; parent sends receipt to MAIN without concurrent file writes.

## Effective L01–L08 scope and closures

L01: exactly31 paths below; early real native observation/expected interface export commit after light tsc, explicitly selected files only, report full SHA+typed signatures+commands to parent/MAIN immediately then continue independent work. Do not use stubs/any/duplicate DTOs. BRIDGE consumes actual immutable candidate, no hand-copied runtime placeholder.
L02/L03: BRIDGE alone owns same-DB opaque commit/join scope, complete plan hash/unique approval and two narrow effects; PRODUCT does not edit core/DDL or invent Approved boolean. Consume actual decision/Context independently of commit/Ack.
L04 closes I3: actual publishReviewPackage already writes legitimate ReviewPackage artifact_version/head; Context.artifacts naturally supplies its immutable Ref. Preserve packageDigestOf; BRIDGE supplies transactional package↔receipt/object binding and result_ref. Parts are not ArtifactPut scripts; reads never render or register.
L05 closes I1/I4: exact additional POST /narralens/native/observation (+1 separately counted) before native-write catch-all; JSON native cookie+Native-CSRF/session-only, closed envelope format/sequence/event_kind/event, document/hydration/selection original schemas. Latest sequence recorded before awaits; authenticated exchange sessionOpened/observe/sessionClosed port from grant.nativeObservation; no client Host identity/revision/proof. NativeObservationService implements original NativeContextPort; BRIDGE injects same instance and closes before DB. Expected interface prove(binding)/assertCurrent(binding,proof)/release(proof)/close is opaque, independently reads complete source and all four parts; 015 alone covers settings/markers only. Final synchronous Ack boundary rechecks sequence/session/generation/view/document/hydration/current commit/control/selection/recovery. Frozen Ack DTO unchanged; selection version Host-owned.
L06 closes I2: select request013-f699-p2-hr1 actual patch f699889206e129dfe4fd913618b34baa8d7e04363f1940d3659664a1e7b9d435 from eeb6c7b0b6c046d39d7c633f4ee0029e23b3f7d6, eight post hashes and actual helper5db47837e690590c9e9678a97e53a10a7115631bd05807ddf6afc925904e2f64; p2 request-start inheritance and H-R1 retained. Reject stale198c active metadata; preserve historical metadata bytes. 015 source7141357f0453caa9253b43098ef43ab50fddeeea five listed source files; copy only explicit native-inputs paths with provenance manifest. Private runtime var/native-hydration-r2, vendor read-only. Build/archive updates only after actual build grant/success; exact managed extraction/path/byte guards remain.
L07: MEDIA exports real CommittedRenderPhasesPort/opaque object resolver and immutable fsynced objects; successful object retained through DB reconciliation, no cross-human-wait FD. BRIDGE owns actual execution/registration/fence. PRODUCT does not implement or fake these other-lane ports.
L08: four actual producers plus guarded consumers before Run availability; early R3 foundations parallel but R2/R3/T20 gates distinct. Heavy slot for Host/media/ffmpeg/browser/build/full, only isolated type/small unit otherwise. Do not run existing integration suites casually if they start Host/listeners. Parent requests slot to MAIN. No artificial budget or attempt cap; real422/529/429 logged, silence is not quota evidence;429 takeover only after invocation/descendants stopped and dirty preserved, >2 stage reworks MAIN root cause.

## Exact31 released product paths

- `src/app/agent-workbench-client.ts`
- `src/app/m5/GatewayApiClient.ts`
- `src/app/m5/M5Panel.tsx`
- `src/app/observation/CreativeReviewPanel.tsx`
- `src/app/observation/NativeSyncIndicator.tsx`
- `src/host/m5/openfilm-studio-gateway.ts`
- `src/host/m5/native-observation.ts`
- `src/host/m5/openfilm-native-expected.ts`
- `src/host/m5/native-ack-store.ts`
- `src/host/m5/openfilm-studio-ui-pin.json`
- `tools/agent-driven/product/build-native-hydration.ts`
- `tests/agent-driven/product/observation-ui.test.tsx`
- `tests/agent-driven/integration/created-native-ack.test.ts`
- `tests/agent-driven/integration/created-workbench-review.test.ts`
- `tests/agent-driven/integration/created-workbench-headless.test.ts`
- `contracts/native-observation-v1.schema.json`
- `contracts/native-observation-v1.registry.json`
- `src/host/m5/controlled-studio-access.ts`
- `src/host/m5/controlled-studio-browser.ts`
- `src/host/m5/studio-host-bridge.ts`
- `src/host/m5/managed-editor.mjs`
- `src/host/m5/managed-editor.d.mts`
- `src/host/m5/managed-editor-pin.json`
- `src/host/m5/managed-editor-dist.tar.gz`
- `src/host/m5/isolated-studio.ts`
- `tools/agent-driven/product/native-inputs/request013.patch`
- `tools/agent-driven/product/native-inputs/expected-projection.mjs`
- `tools/agent-driven/product/native-inputs/expected-projection.d.ts`
- `tools/agent-driven/product/native-inputs/native-pure.entry.ts`
- `tools/agent-driven/product/native-inputs/vite.expected.config.mjs`
- `tools/agent-driven/product/native-inputs/build-expected.mjs`


All other source remains protected, including static validator generator/public contracts/other-lane ports. Preserve exact public DTO/static browser validator/CSP fixes; no app Host imports/dynamic compiler. Reuse P03/P05–10 cases and genuine old-browser regression with new interfaces; each real E2E awaits actual peers, no production fakeRun. No broadadd/push/reset/stash/merge/install/network/J/config/credential access. Capture commands, failures, scopes, raw logs+hashes, final exact SHA and own cleanup. Scoped Codex review follows writer settlement; not independent/A/human PASS and no B.
