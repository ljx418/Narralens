# A-R1-PRODUCT APP CORRECTION — 实现结果（2026-11-11）

本文件是本票**实际源码修复**的交付记录。它不是 A 验收、不是独立审查、不是人验；它只是本 lane 的实现者对自己这次改动的自测证据，交父 Codex 只读复核。

## 0. 身份、范围与基线

- 本子 Task `task_fd72cf314413`，Dispatch `ctx_fadcf96e0143`，终端 handle `term_e00cada8-7fe8-4909-84ca-7adf78776640`。
- 父 Codex `term_dbe899889c960daeaba8b5f3ba7fe6e2`（父 task `task_9e9e39498505`，父 dispatch `ctx_3481af515722`）。
- 会话自报模型：`MiniMax-M3.1-Flash-Preview[1m]`（运行环境注入的会话自报字符串）。**未**读取 `~/.claude`、`~/.codex`、`.env`，**未** dump env 来"证明"供应商；凭据处置沿 MAIN 的 UNKNOWN。
- 实际 cwd `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT`；实际 base/full HEAD `6ce5c2cc93fef0d37fc99c49c505b182bf62a05f`。
- 本次冻结提交：`64f66ff`（`fix(A-R1 PRODUCT): correct the app against the reviewed contracts`），只含上表 11 个 app/test 路径；未 push、未合 main。
- 本票唯一 writer=本 Claude；父 Codex 只读；**未**启动任何 helper/subagent。
- 本次改动的文件（`git diff --name-only HEAD`，11 个，全部在本票允许路径内）：

  | 路径 | 说明 |
  | --- | --- |
  | `src/app/agent-workbench-client.ts` | 真实 validator、审定的附属素材协议、descriptor 严格校验、请求键绑定 |
  | `src/app/m5/GatewayApiClient.ts` | authenticated fetch 的 AbortSignal |
  | `src/app/m5/M5Panel.tsx` | 观察刷新、单一 clock、预览生命周期、采用/决定分离 |
  | `src/app/observation/CreativeReviewPanel.tsx` | busy/stale 禁按钮、受控引用、纯 accept 与采用分离 |
  | `src/app/observation/LocalAssetRegistrationPanel.tsx` | 枚举化录制来源、source.uri/derived、meta 由客户端绑定 |
  | `src/app/observation/content-views.tsx` | VTT/JSON 安全文本展示、HTML 拒绝 |
  | `src/app/observation/index.ts` | 导出新增类型与 `PreparedTextView` |
  | `src/app/observation/observation.css` | 预览 transport 与安全文本的样式 |
  | `tests/agent-driven/product/observation-ui.test.tsx` | 负向用例 + M5 挂载生命周期用例 |
  | `tests/agent-driven/product/local-asset-registration.test.tsx` | 审定形状的素材登记用例 |
  | `tests/agent-driven/integration/created-workbench-review.test.ts` | 客户端真实校验负向矩阵 |

- **MAIN 传输修正三文件保持字节不变**（本票不得编辑/回滚/运行其测试）：

  | 文件 | SHA256 | 相对 HEAD |
  | --- | --- | --- |
  | `src/host/m5/controlled-studio-access.ts` | `8d8825ea2392dec02040e728579abd522d202bb4fe56a027fba9515c0fa68ac6` | UNCHANGED |
  | `src/host/m5/openfilm-studio-gateway.ts` | `451e0ba8e8c2013f2eff429b66e57a2d62659b97d86e9fff809e32f50a11f2a2` | UNCHANGED |
  | `tests/agent-driven/integration/created-native-ui-transport.test.ts` | `45ff1305610632ed0870e5c6cb96242737dc6a123fe3300012dd5eb1c2307fd1` | UNCHANGED |

  `git diff 6ce5c2c -- <上述三文件>` 为空。本票**未**运行 `created-native-ui-transport.test.ts`（被 hold）。

## 1. 逐缺陷结果

### 缺陷 1 — 素材清单/库存/登记的协议形状与声明

- **PASS**。`readCandidates`/`readInventoryItems` 不再猜 `candidates`/`files`/`assets`：现在只接受审定的 `SourceFileListing`（`format=narralens.local-source-files@1`，`items[]`，候选 `display_name`/`kind`/`bytes`/`expires_at`）与 `Inventory`（`format=narralens.asset-inventory@1`，`items[]`，条目 `source_label`/`license{status,label,commercial_use}`/`recording_origin`/`media`/`rights_ref`）。多一个字段、少一个字段、另一种拼法、别的 `format` 一律抛 `INVALID_SOURCE_FILE_LISTING` / `INVALID_ASSET_INVENTORY`，不再"猜一种能读的"。
- **PASS**。登记请求补齐 `meta`（`idempotency_key`+`correlation_id`）与 `source.uri`；`recording_origin` 只接受 `human_recording|synthetic|unknown|null`，自由文本在客户端被拒（`INVALID_RECORDING_ORIGIN`）；`source` 支持审定的两个变体（`owned|generated|licensed` + `uri`，`derived` + `lineage`）。
- **PASS**。`meta` 由客户端按**完整声明**（project/candidate/source/label/uri-or-lineage/license/origin）绑定：同一份声明永远复用同一个 `idempotency_key`（未知结果不换键），声明一变（换 source/uri/许可/origin）就是新请求、拿到新键。面板在失败后显示该键，供对账。
- **PASS**。分页与失效诚实：读取 `cursor_next`，非空时明确告诉操作者"只展示第一页"；Host 回 `410`（候选/游标过期）时提示刷新而不是重试；工程切换时清空候选与清单（`localAssetsProject`）。
- **PASS**。测试用审定 schema 的真实 shape 抓住旧实现：`refuses a candidate listing in the old guessed shapes`、`refuses an inventory in the old guessed shape`、`refuses an inventory item whose recording origin is free text`。

### 缺陷 2 — 客户端真实校验与采用/决定分离

- **PASS**。`readContext`/`readWorkflow`/`readReview`/`readHealth`/`decideReview` 全部改用冻结的 `validateAgentDefinition`（`Context`/`Workflow`/`ReviewPackage`/`ReviewDecision`/`HealthRead`），不再只是 cast；缺字段、多字段、错类型都被合同自己的 validator 拒绝（`INVALID_CONTEXT` 等）。
- **PASS**。身份核对：`readReview` 核 `project_id`/`run_id`/**`package_id`**；`decideReview` 先核 `package.project_id === client.projectId`（否则 `PROJECT_MISMATCH`，**一个请求都不发**），回包再核 `project_id`/`package_id`/`package_version`/`run_id`。
- **PASS**。`describePart` 不再只看 `format`：descriptor 的**每一个字段**都按 CR-R1-001 §8 校验（`package_digest`/`receipt_digest`/`sha256` 为 64 位小写十六进制；`part` 为完整 `ReviewPart`（kind + Ref + download_ref 令牌）；`object_id`/`content_type`/`bytes`；`timeline`；`media_facts` 判别联合四分支各自字段），多一个未知字段即拒绝。
- **PASS**。纯 accept 与采用状态分离：面板的 `decision` 与 `adoption` 仍是两个独立事实；`accept_and_adopt` 才带 Host 的 `approval`，纯 `accept` 的 `approval` 必为 `null`（冻结合同的 `allOf/if-then` 亦如此）。
- **PASS**。busy/stale 禁按钮：`CreativeReviewPanel` 新增 `busy` 与 `stale`；包状态不是 `pending`、有决定在途、或上次读取失败（stale）时按钮禁用并给出原因。
- **PASS**。成功后重读事实：决定成功后重新读 `context` 与当前 `review` 包，面板显示的是 Host 现在的说法。
- **PASS**。M5 从**当前 pending gate** 选包：`gates.find(g => g.state === "pending" && g.review_package_id !== null)`，不再取"第一个有 package 的历史 gate"（用例断言读到的是 `package-1` 而不是历史 gate 的 `package-old`）。

### 缺陷 3 — M5 观察不再"一次读取后永久 connected"

- **PASS**。观察改为经**真实 read transport** 的有界刷新（5s 定时器 + `AbortController`），记录 `observedAt`（ISO 时间）与 `connection`（`connected`/`unknown`）。
- **PASS**。读取失败 → `connection=unknown` 并显示真实原因；**不**清空最后一次已知事实、**不**伪造进度或 `loaded`；下一次成功读取自动恢复为 `connected`。
- **PASS**。换工程/换 run 时旧 state 清空（观察 effect 在 `uiClient` 变化时清空 workflow/context/health/review/decision 并作废旧游标键）。
- **PASS**。迟到结果不得覆盖新 scope：每次观察有 generation 号，回包落地前核对 generation 与取消标记；用例 `does not let a late answer of the previous scope land on the new one` 让旧 scope 的 `workflow.read` 在新 scope 之后才 resolve，断言旧 workflow 没有落地。

### 缺陷 4 — 预览：暂停原生、唯一 clock、取消与清理

- **PASS**。预览不再"从未暂停 native"：进入预览前用**上游已有的** `seek` 命令（`{type:"seek", time}`，Studio 侧 `pause(); seek(...)`）把编辑区停在**已观测**的帧；没有观测时明确拒绝并写明"不会猜测 0"（不捏造 pause 命令）。用例断言 `studioCommands` 含 `{type:"seek", time:12.5}` 且无观测时 `studioCommands` 为空。
- **PASS**。预览元素不再自带独立时钟：去掉了 `controls`（浏览器自带 transport 会跑第二只时钟），元素只作为面板唯一 `PlaybackClock` 的投影，由面板自己的 transport（range）驱动；用例断言 `video` 无 `controls`。
- **PASS**。同 clip seek 也会退出预览：原生报告的比较从"只看 clip id"改为"clip id 或时间（±0.05s）变化"；`keeps the preview when the editor reports the same place, and stops it when it really moves` 用例先断言同值报告不退出、再断言同 clip 内 12.5s→20s 退出。
- **PASS**。周期性同值 native report 不当作用户操作（同上用例前半段）。
- **PASS**。abort/generation/unmount 保护：每次打开产生新的 generation 与 `AbortController`；离开/切换预览会 abort 在途读取；unmount 清理**不再用 setState 副作用**，只 abort + revoke URL；旧 generation 的异步回包不会重新打开预览（用例 `never reopens the preview from an answer that arrives after the preview was left`）。
- **PASS**。对象 URL 在切换、退出、unmount 三条路径都被 revoke（用例 `releases the object URL when the preview is left and when the panel goes away`）。
- **PASS**。原 clip 选择在 review 时不再静默无操作：`selectClip` 在 review 模式先退出预览，再真正执行选择（回到原生时间线继续编辑）。

### 缺陷 5 — descriptor/媒体/受控引用校验

- **PASS**。`package_digest`/`receipt_digest`/`sha256` 必须是 64 位小写十六进制；`part.kind` 与包的 part 一致；`part.artifact_ref`（id/version/sha256）与 `part.download_ref` 完整绑定；`object_id` 是受控令牌；`content_type` 与 `media_facts.kind` 一致（video→`video/*`、audio→`audio/*`、text/json→文本类）。
- **PASS**。`frame_count` 与 `timeline.frame_count` 必须一致（不再只检查"正数"）；帧率必须与**项目 clock** 有理相等（clock 现在取投影的真实 fps，而不是写死 30/1），不符明确拒绝且不改原 clock；音频的 `sample_count/sample_rate` 与时间基长度之差不得超过一帧。
- **PASS**。VTT/JSON 以**安全文本**显示（`PreparedTextView`，React 转义，无 `dangerouslySetInnerHTML`），HTML 明确拒绝并显示拒绝原因；用例断言 `document.querySelector("script")` 为 null、`<script>` 不出现在 HTML 中。
- **PASS**。受控引用不再"取任意外部 URL 尾部"：`download_ref` 必须是冻结合同的令牌（`^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$`），面板的下载地址只由本实例 base + 该令牌拼出，外部地址显示为不可用。
- **PASS**。`GatewayApiClient` 的 authenticated fetch（`uiCall`、`reviewMedia`）接受并传递 `AbortSignal`，ETag/hash/bytes 校验与错误语义原样保留。
- **PASS**。二进制不代表 committed/Delivery：预览仍标注"准备内容，尚未采用，也不是正式交付"；登记成功只说"清单里有了 <asset_id>"。

### 缺陷 6 — 测试

- **PASS**。三份允许的测试文件共 88 个用例全绿（45 + 13 + 30）。新增的负向/生命周期用例覆盖：合同真实 shape 与必填字段、稳定同键、错 scope/错回包、断连、迟到回包、预览取消/clock/同 clip 操作/清理、descriptor 多字段负向、素材清单/库存旧形状拒绝、录制来源枚举。
- 说明：这些是**组件与客户端层**证据（无 listener、无端口、无真实 Host/媒体/浏览器），不是生产者—消费者证明。

## 2. 命令证据（真实 argv / cwd / 起止 / exit / log SHA256）

cwd 全部为 `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT`；日志与元数据在 `docs/parallel/lane-product/A-R1-20261111/logs/`。

| 日志 | argv | exit | log SHA256 |
| --- | --- | --- | --- |
| `app-correction-tsc.log` | `corepack pnpm exec tsc --noEmit` | 0 | `2462184396ae02af1f069b9fc0f6c79285c6521c465555e71c61a2f008f72e68` |
| `app-correction-tests.log` | `corepack pnpm test tests/agent-driven/product/observation-ui.test.tsx tests/agent-driven/product/local-asset-registration.test.tsx tests/agent-driven/integration/created-workbench-review.test.ts --maxWorkers=1 --minWorkers=1` | 0 | `c795c86c435b3f05e242fac19768d35e45d7300ea39a76e880c7beb6343471b4` |
| `app-correction-architecture-fitness.log` | `corepack pnpm test tests/architecture --maxWorkers=1 --minWorkers=1` | 1 | `42d255930442659259d7841e9be29bf85e1d17b89826fef47053c7e024ad4dfc` |

每个 `.meta` 文件记录了 argv、cwd、start/end(UTC)、exit 与 log SHA256。

**首失败说明（架构套件 exit=1）**：`tests/architecture/m2.2-fitness.test.ts` 的 2 个用例失败，报 `src/host/agent-driven/created-task-store.ts` 与 `src/host/projects/project-creation-store.ts` 越权写 job state。这两个文件**不在**本票允许路径内，本票也**未**修改它们（`git diff --name-only HEAD` 只含上表 11 个 app/test 文件），且它们的最后一次改动来自 `9f58323`（R0 冻结）与 `76607c1`——即**在本票开始前就已存在的红灯**，属 Host/其他 owner 的根因，不在本票处置范围。

**本次修复的一处既有红灯**：上一候选 `df32311` 让 `src/app/agent-workbench-client.ts` 从 `../host/render/assembly-ports.js` 导入 MEDIA 类型，触犯了仓库冻结的依赖方向规则（`tests/architecture/m2.1-fitness.test.ts` fitness 1："app code never imports host"），该用例在 base 上是红的。本票在允许范围内修掉了它：app 不再 import `src/host/**`，改为自己持有"线上形状"的消费侧结构类型（逐字段校验，见缺陷 2/5）。这**不是**降 guard、不是改冻结合同、不是新增文件；相关请求见第 4 节。

## 3. NOT_RUN（明确未跑）

| 项目 | 原因 |
| --- | --- |
| `corepack pnpm build` / `vite build --config vite.m5.config.ts` | 需 MAIN 重型资源预约（构建槽），本票未获槽。**特别提示**：本票让 app 首次引入冻结合同的 Ajv 校验器（`src/contracts/agent-driven-validator.ts`），面板 bundle 体积会变化，体积与打包可行性**尚未验证**，须在 MAIN 槽内确认。 |
| `corepack pnpm test tests/agent-driven/integration/created-native-ui-transport.test.ts` | 被 hold 的 MAIN 传输测试，本票不得运行。 |
| 任何 Host / listener / ffmpeg / Chromium / 媒体 / 全量 `pnpm check` | 需 MAIN 单槽预约，未获槽。 |
| 真实 Studio / 真实 Host / 真实准备媒体的端到端预览 | R1 尚无生产者接线（见第 4 节），本票只能给组件与客户端证据。 |

## 4. 真实 producer 依赖（请 MAIN / BRIDGE / MEDIA 处理）

1. **BRIDGE：附属素材协议的运行时 DTO 与 validator 不在本 checkout**。本票按已审附属 schema（`docs/execution/A/relaunch-20261111/contracts/asset-inventory-v1.schema.json` + `asset-inventory-v1.registry.json`）在 app 侧做精确形状与枚举校验，未猜多种格式、未造生产替身。需要 BRIDGE 提供该协议的运行时导出（以及 `local-assets.v1` 的实际 handler），否则 `local-assets.v1/*` 与 `workbench.v1/review.part.describe` 在真实运行时是 503（app 如实显示"不可用"，不伪造）。
2. **BRIDGE/MEDIA：`PreviewMediaDescriptorV1` 的权威类型位置**。权威定义在 `src/host/render/assembly-ports.ts`（MEDIA owner），但 app 不得 import `src/host/**`（冻结依赖方向规则）。本票因此在 app 侧持有"消费侧结构类型"并逐字段校验。请 MAIN 协调把同一类型暴露到 **contracts 归属**的模块（或由 MAIN 裁定 app 侧持有的方式），避免两处漂移。
3. **附属读取的游标入参名未定**。已审 registry 只写明"opaque cursor，410 表示失效"，没有给出 UI RPC 里承载 cursor 的入参字段名。本票**不猜**这个字段（猜了会被 Host 的 DTO 校验按未知字段拒绝），只读 `cursor_next` 并如实说明"只展示第一页"。需要 MAIN/BRIDGE 明确游标入参名后，本票可一行接上。
4. **`review.part.describe` 与 `local-assets.v1` 需进运行时 registry**（`contracts/agent-workbench-ui-v1.registry.json`，BRIDGE 唯一编制）。本 checkout 中该 registry 不存在，故 Gateway 对这些组合一律 503（`openfilm-studio-gateway.ts` 的既有行为，未改）。

## 5. 进程与清理

- 本票**未**启动任何服务、listener、浏览器或后台进程；所有命令均为前台一次性 `pnpm test` / `tsc`。
- 未安装、未联网、未读 J 盘、未付费、未外传素材、未改模型或供应商、未读 `~/.claude`/`~/.codex`/`.env`、未 dump env。
- 未 `git push`、未合 main、未 `reset`/`stash` 用户工作；**冻结提交只显式 add 本票的 11 个 app/test 路径**（本票文档与日志留在工作树未跟踪状态，与本票开始前该目录的未跟踪状态一致；父 Codex 决定何时纳入版本库）。

## 6. 交回

写权在本条 `worker_done` 后交回父 Codex 只读复核。本文件与 `HANDOFF.md` 是本票的实现者自证，**不构成** A 阶段通过、**不构成**独立审查、**不构成**人验，**不进入** B。
