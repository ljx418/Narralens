# A-R1-PRODUCT Claude 实现结果（2026-11-11）

本文件是 PRODUCT lane 的实现候选自述。它不是产品验收，不是独立审查，也不是人验。

## 身份与注入

| 项 | 值 |
|---|---|
| 实际子 Task | `task_7afe2fb90cf2` |
| 实际子 Dispatch | `ctx_cb5959acbeb8` |
| 实际子终端 handle | `term_491735f2-627f-42e6-b7e2-c2143a9b6e8c` |
| 父 Codex | `term_dbe899889c960daeaba8b5f3ba7fe6e2`（task `task_9e9e39498505`，dispatch `ctx_3481af515722`） |
| MAIN | `term_a731c232-35c7-4f55-a75d-9b2beeade398` |
| launch 回执 | 父 Codex 回执原文：state ready，task/dispatch/terminal 如上，keptOpen true，父 task/dispatch 如上；并注明第一次 stdin launch 因 PowerShell 参数解析失败、worker-list 证明未创建子进程，本次 UNC-path launch 是唯一实际子进程，不是重复 |
| 会话自报模型 | `MiniMax-M3.1-Flash-Preview[1m]`（运行环境注入的会话自报字符串；未读取 `~/.claude`、`~/.codex`、`.env` 或 dump env 来"证明"供应商） |
| 凭据处置 | UNKNOWN（沿 MAIN 的 AUTHORIZATION_INTERPRETATION；本 lane 未读改任何配置或凭据，未切模型/供应商） |
| 子任务 | 无 helper 启动 |

## 基线与实际 HEAD

- R1 base/full HEAD（本票开始时）：`84deba07927fa59b45a24039b4740a2f9d3fd430`
- 早期类型候选提交（本人显式提交）：`535ad0c003ede9be258044809a002cdf33ad53d3`
- MAIN 集成 MEDIA 类型后 HEAD：`6bcdd8b1a33c64e53405a390eae8e23c1c44a5b0`
  （MEDIA `24e3576d…` → `413f733…`，`01712e7b…` → `6bcdd8b…`；仅 `assembly-ports` 变化；22 个原 dirty/未跟踪文件哈希不变，index 干净；证据 `MEDIA_TYPE_INTEGRATION.json`）
- 本票未 push、未合主干、未 reset/stash、未跨分支 cherry-pick。

## 交付的实现（23 个释放路径中的 16 个被改动）

### 传输与授权（Host 侧）

- `src/host/m5/controlled-studio-access.ts`
  - 导出 `NativeStudioUiGrantV1`（`project_id`/`owner_session_ref`/`instance_generation`/`expires_at`/`isCurrent()`/`invoke({surface,operation,input,correlation_id})`/`openReviewMedia({ref,range?})`）与可选 `NativeStudioGrant.ui`；无 `ui` 的旧 native 调用方不受影响。
  - `ControlledStudioAccess` 持有**独立** UI cookie（`narralens_ui_<hex>`）、独立 secret、独立 proof map（`#uiProofs`）与独立 retired map；UI 证明头 `X-Narralens-Workbench-CSRF`，**不**由 native 证明派生。
  - UI 收集独立（`#collectUi`）：native 会话 stale 不会连带撤销仍有效的 UI delegate；UI 有效期 `min(grant.ui.expires_at, now+8h)`。
  - `mintUi` 在签发凭据前复核 native 与 UI 两侧的 parent 活性，并拒绝 project/owner/generation 不一致的 delegate。
  - `invokeUi` 在转发前拒绝 body 中属于别的 `project_id`；`openUiMedia` 校验 ref 与 range，并把**单次 read** 上限收敛到 MEDIA 的 `PREPARED_REVIEW_MAX_READ_BYTES`（请求区间可更大，由调用方分段读）。
  - 打开后若 parent 被撤销，先 `close()` 再抛出（调用方拿不到泄漏的 reader），并有回归。
- `src/host/m5/controlled-studio-browser.ts`：entry 只在 Host 真正签发 `narralens.gateway-ui-session@1` 时写入本 tab 的 UI 会话；transport 脚本只对 `/narralens/api/ui/` 加 UI 头，native 头照旧共存但**不**代表 UI 权力；调用方自带的同名头不被覆盖（由 Gateway 判否）。
- `src/host/m5/openfilm-studio-gateway.ts`：新增**恰好两条** Gateway 别名（`POST /narralens/api/ui/call`、`GET /narralens/api/ui/review-media/:ref`），并导出 `GATEWAY_UI_ALIASES` 与 `GATEWAY_UI_EXPOSURE_COUNTING`（"31 frozen Host + 5 reviewed adjunct Host + 2 explicitly additional Gateway HTTP"，不声称总数仍是 31+5）。
  - 闭集校验：envelope 恰好 `{surface,operation,input}`；surface 限三面；operation 限运行期 registry；registry 缺失时 **503 CAPABILITY_UNAVAILABLE**，不自造 allowlist。
  - 媒体别名：ETag 为带引号的 sha256，`Content-Range`/`416` 语义，**大于 1MiB 的 range 以分段有界读实现**（不是拒绝），短读视为对象已变而拒绝，finally 关闭 reader。

### 消费者（应用侧）

- `src/app/agent-workbench-client.ts`（新）：闭集 UI RPC 的类型化客户端（`agent.v1`/`local-assets.v1`/`workbench.v1`），固定 project；`describePart` 消费 **MEDIA 已集成的 `PreviewMediaDescriptorV1`**（不再自造第二份 receipt/descriptor 协议）；`readCandidates`/`readInventoryItems` 按冻结 inventory 形状读取，认不出的条目直接忽略而不是猜。
- `src/app/m5/GatewayApiClient.ts`：`uiCall`（独立 UI 头）与 `reviewMedia`（返回原始 bytes + ETag），`uiProofHeaders()` 只读本 tab 的 UI 会话，`sha256Hex` 供预览核对。
- `src/app/m5/M5Panel.tsx`：在原 M5 内增量挂载 `WorkflowTopBar`（默认折叠）、`SystemControlPanel`（非模态 aside）、`CreativeReviewPanel`、`LocalAssetRegistrationPanel`、`NativeSyncIndicator`，以及**一个**准备预览槽位。
  - 预览顺序：descriptor → 身份/版本/摘要核对 → 媒体事实与**唯一 PlaybackClock** 的有理帧率精确比对 → 取字节 → 核对 ETag/摘要/长度 → 才建 object URL；任一步失败都拒绝并说明具体原因。
  - review 模式隔离原生 selection 与键盘 seek；原生时间线**真实**变化才退出预览并保留原 clock；预览不自动播放；退出/unmount 时 revoke object URL。
- `src/app/observation/CreativeReviewPanel.tsx`：决定与采用分事实展示（"决定已登记"≠"已采用"）；复用包显示真实 lineage；`download_ref` 只在属于本实例受控地址时给链接，否则显示不可用；明确"准备内容，尚未采用，也不是正式交付"。
- `src/app/observation/LocalAssetRegistrationPanel.tsx`（新）：只列受控候选，无路径框、无上传、无自动授权；post 只有 `project_id`/`candidate_id`/`source`/`license`/`recording_origin`。
- `src/app/observation/NativeSyncIndicator.tsx`（新）：从 `content-views.tsx` 抽出，**唯一实现**；`content-views.tsx` 与 `index.ts` 保留原导出路径。
- `src/app/observation/index.ts`、`src/app/observation/observation.css`：导出与样式（本地素材面板、决定行、采用行）。

### 明确未改动的释放路径及原因

- `src/app/m5/SelectionCoordinator.ts`：准备预览**不得**伪装成 committed clip，所以没有新增任何选区写入；仍只有它一个选区 writer。
- `src/app/main.tsx`、`src/app/owned-project-client.ts`：原生工作台是 Studio 页内的 M5 面板（UI delegate 在 native-open 兑换时铸造，故观察面挂在 M5）；owned 根没有"已选工程但未打开"的状态，强行挂载只会展示空面。
- `src/app/system/SystemControlPanel.tsx`、`system/index.ts`、`system.css`：既有非模态 aside 实现已符合要求，只在 M5 里挂载并把样式引入面板 bundle。

## 逐 case 与命令证据

| 命令 | cwd | 起止 | exit | 结果 | 日志 SHA256 |
|---|---|---|---|---|---|
| `corepack pnpm exec tsc --noEmit`（早期类型候选） | 本 checkout | 21:59:40 → 21:59:49 | 0 | 通过 | `tsc-early-type-candidate.log` `5176781394354aa4668752676af96978c43ea2098448998d1ffefca0fde8b41e` |
| `corepack pnpm exec tsc --noEmit`（别名后） | 同 | 22:03:26 → 22:03:33 | 0 | 通过 | `tsc-ui-aliases.log` `e17c046bf8b1f994396ed4556ca030e6694dac3a02e59ff8408bec082ced7695` |
| `corepack pnpm exec tsc --noEmit`（transport 测试后） | 同 | 22:06:04 → 22:06:09 | 2 → 修复后 22:06:18 → 22:06:25 exit 0 | 首错＝测试自身类型错误（registry `null` 未被 deps 接受、`closes` 只读），已修 | `tsc-transport-test.log` `ed00e856d51d068e4e64c11856ec94a0cf65c7be3407f6882acb63c4d6f9efad` |
| `corepack pnpm exec tsc --noEmit`（消费者后） | 同 | 22:17:42 → 22:17:51 exit 2 → 22:18:12 → 22:18:19 exit 0 | 首错＝`inventory`/`ui` 与既有 M5 状态重名、`BlobPart` 类型不符，已重命名并改为 `ArrayBuffer` | `tsc-app-consumers.log` `8dc0529983557ce38415a5693c292ea3099c7118764e819df31e619f1010a7bf` |
| `corepack pnpm exec tsc --noEmit`（消费 MEDIA 类型后） | 同 | 22:24:03 → 22:24:10 exit 0；22:24:39 → 22:24:47 exit 0 | 通过 | `tsc-media-types.log` `5ada2beff767c60f814098201b05e08c3ed7da179f14416a35786cf3846abb14` |
| `corepack pnpm test tests/agent-driven/integration/created-native-ui-transport.test.ts --maxWorkers=1 --minWorkers=1`（MAIN 槽 `R1-PRODUCT-TRANSPORT-001`） | 同 | 22:09:45 起，四次运行 | 1,1,1,0 | **21/21 通过**（run 4）；首失败与三次夹具修正见下 | `created-native-ui-transport.test.log` `805d5ba727e94cedfd52897c110b8bc1d1fa94c98f4a1854ba2724ae034bd837` |
| `corepack pnpm test tests/agent-driven/product/local-asset-registration.test.tsx --maxWorkers=1 --minWorkers=1` | 同 | 22:19:38 exit 1；22:19:47 → 22:19:48 exit 0 | 1 → 0 | 首错＝候选 label 带 detail 时精确 label 查询失败，改用正则后 **8/8 通过** | `product-local-asset-registration.log` `7e65adf8f488b01c9b00aea649025c03c84cd4765f5b041af34485a248ec7cc3` |
| `corepack pnpm test tests/agent-driven/integration/created-workbench-review.test.ts --maxWorkers=1 --minWorkers=1` | 同 | 22:20:30 exit 1；22:20:41 → 22:20:42 exit 0 | 1 → 0 | 首错＝期望的 decision 键漏了 `project_id`，改正后 **10/10 通过** | `created-workbench-review.test.log` `64d2a8897744aa3356d77d5d18b11bde3936f27f93a52ef238109648bcb7880f` |
| `corepack pnpm test tests/agent-driven/product/observation-ui.test.tsx tests/agent-driven/product/local-asset-registration.test.tsx --maxWorkers=1 --minWorkers=1` | 同 | 22:21:10 → 22:21:13 | 0 | **37/37 通过** | `product-observation-ui.log` `7c188dedc9561d79865eeab1828ee13e8d50ac173a72ecb326c4f7b545376660` |
| `corepack pnpm test tests/agent-driven/product/observation-ui.test.tsx tests/agent-driven/product/local-asset-registration.test.tsx tests/agent-driven/integration/created-workbench-review.test.ts --maxWorkers=1 --minWorkers=1` | 同 | 22:25:01 → 22:25:02 | 0 | **47/47 通过**（消费 MEDIA 类型后复跑） | `product-and-review-light.log` `3d94469f14fb852cd39febb187386b19e35887fbf375bafab140d47dddeb4db8` |

## 原失败与 NOT_RUN

- transport 测试四次运行的原始失败全部保留在 `created-native-ui-transport.test.log`：run1 exit 1（20 失败/1 通过；夹具 cookie 名匹配写错，且一个用例用了根本无法签发的 revoked native grant）、run2 exit 1（2 失败/19 通过）、run3 exit 1（1 失败/20 通过；`node:http` 会替换同名头，重复头未真正发出）、run4 exit 0（21/21）。三次都是**夹具/断言自身**的修正，没有放宽生产 guard。
- **transport 阶段已按 MAIN 要求暂停**，等待 MAIN 对 >2 次阶段返工的根因处置；此后未再改动 `src/host/m5/*` 的 transport 输入，也未再重跑该文件（除类型检查外）。
- **NOT_RUN**：`corepack pnpm build`、`corepack pnpm run test:m5:headless`、全量 `corepack pnpm check`、真实 Studio/Chromium/ffmpeg/真实媒体、真实 Host 应用装配、真实 BRIDGE dispatcher 与真实 prepared media —— 都需要 MAIN 重型槽或真实生产者，本票未获槽、未具备生产者。
- 清理证据的**限制**：transport 测试每个用例的 Gateway 端口号未逐例记录（端口由 OS 随机分配，`port: 0`），因此**没有端口级核对**；`ss` 显示"有属主的监听"并不能证明我方无残留，不能当作该证明。实际证据是：记录的 shell PID 768624 已退出；每个用例在 `finally` 里 `gateway.close()`；事后无属于本 lane 的 vitest/narralens 进程；无属主已死的监听 socket。

## 需要别的 owner 提供的东西（本 lane 未造替身）

1. **BRIDGE**：`creation-application` 在已认证 `trusted_ui` 分支铸造并传入 `grant.ui`（`NativeStudioUiGrantV1`），否则 native 入口保持 native-only（这已被测试证明是正确行为）。需要 `grant.ui.invoke` 与 `grant.ui.openReviewMedia` 的真实实现。
2. **BRIDGE**：运行期 registry `contracts/agent-workbench-ui-v1.registry.json`（面/操作闭集）。缺失时两条 Gateway 别名一律 503，不伪造可用。
3. **BRIDGE**：`agent.v1` 各操作的真实 handler（`workflow.read`/`context.read`/`review.read`/`review.decide`/`health.read`）、`local-assets.v1` 的四个操作，以及 `workbench.v1/review.part.describe` 的真实 descriptor（BRIDGE 依 MEDIA 的 `PreparedPreviewReceiptV1` 与 `PreparedReviewMediaReader` 构造）。
4. **MAIN**：真实装配（Gateway 的 `uiRegistry` 注入、Host 的 `grant.ui` 铸造、面板 bundle 的构建）。

## 明确不声称

- 不声称 A/V1 通过，不声称 R2（采用/原生确认）或 R3（交付/QC）完成。
- 不声称 transport 的 21/21 等于真实 Studio/真实 Host 应用集成：它用的是 **stub Studio** 与临时 loopback Gateway，属**组件传输证据**。
- 模拟/fixture 只证明组件与协议边界；缺生产者的面一律显示 unknown/blocked，不显示"可用"。
- 本 lane 未自签独立审查或人工验收；后续由 Codex 分时只读复核、MAIN 统一验收。
