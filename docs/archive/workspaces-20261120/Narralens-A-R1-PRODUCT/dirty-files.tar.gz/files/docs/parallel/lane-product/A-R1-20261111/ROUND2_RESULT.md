# A-R1-PRODUCT ROUND 2 — APP CORRECTION 结果（2026-11-11）

本文件是本票**第二轮 app 修复**的实现记录。上一轮见 `APP_CORRECTION_RESULT.md`（冻结提交 `64f66ff`，保留未改）。本轮**不是** A 验收、不是独立审查、不是人验。

## 0. 身份、基线与范围

- 子 Task `task_286f4f808d2f`，Dispatch `ctx_0597618c1f71`，终端 handle `term_7236e5aacafeb4e0d8a970eec408d445`。
- 父 Codex `term_dbe899889c960daeaba8b5f3ba7fe6e2`（父 task `task_9e9e39498505`，父 dispatch `ctx_3481af515722`）。父回执：`msg_4cde4cb3a16c`（MAIN 决定）、`msg_3d64c4ddb557`（CR-R1-002 分页批准）、`msg_a37ef53cee78`（安全暂停，导入公共模块）。
- 会话自报模型 `MiniMax-M3.1-Flash-Preview[1m]`；未读 `~/.claude`/`~/.codex`/`.env`，未 dump env；凭据处置沿 MAIN 的 UNKNOWN。**未**启动任何 helper/subagent。
- 实际 cwd `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT`；本轮起点 HEAD `64f66ff`，**本轮冻结提交 `e6c03a7f465b5ee205aad8dc4e27e78e1cabe7a6`**。
- 本轮改动文件（6 个，全部在本票允许路径内）：`src/app/agent-workbench-client.ts`、`src/app/m5/M5Panel.tsx`、`src/app/observation/CreativeReviewPanel.tsx`、`src/app/observation/LocalAssetRegistrationPanel.tsx`、`tests/agent-driven/product/observation-ui.test.tsx`、`tests/agent-driven/integration/created-workbench-review.test.ts`。
- **MAIN 传输修正三文件字节不变**（不得编辑/回滚/运行其测试）：`controlled-studio-access.ts` `8d8825ea2392dec02040e728579abd522d202bb4fe56a027fba9515c0fa68ac6`、`openfilm-studio-gateway.ts` `451e0ba8e8c2013f2eff429b66e57a2d62659b97d86e9fff809e32f50a11f2a2`、`created-native-ui-transport.test.ts` `45ff1305610632ed0870e5c6cb96242737dc6a123fe3300012dd5eb1c2307fd1`；`git diff 6ce5c2c -- <三文件>` 为空；被 hold 的 transport 测试**未**运行。

## 1. 逐条修复

### A. 准备预览真正能播、能听

- **PASS**。预览新增显式**播放/暂停**按钮（`data-nl-preview-play`）。点击"播放"时：媒体元素**真的 `play()`**（音频因此可听），唯一 `PlaybackClock` 随之推进；元素只在漂移超过 0.25s 时被纠正，播放过程不抖动。
- **PASS**。时钟与媒体一致：打开预览时时钟被 seek 到**已观测帧**（`clock.frameFor(observed.seconds)`），编辑器被暂停在同一帧；面板只有一个位置来源。
- **PASS**。只有一个音频焦点：预览元素不静音；预览占用期间三路 proxy 全部静音并停止（proxy 与预览按工程格式互斥，但仍显式互斥）。
- **PASS**。**不自动播放原生**：面板只对原生发 `seek`（上游唯一会 pause 的命令），从不对原生调用 play；用例断言编辑器只收到 `[{type:"seek",time:12.5}]`。
- **PASS**。结束/错误/暂停/退出清理：`ended` → 停时钟并落在最后一帧；`error` → 停时钟并说明原因；`pause` → 停时钟；退出预览/切换/unmount → 停时钟、暂停元素、abort、revoke 对象 URL。
- **PASS**。测试不是"断言没有 controls"：用例 spy `HTMLMediaElement.prototype.play`，断言 `play` 被调用、`element.paused === false`，并断言 `data-playhead` **真的变大**；变异测试（去掉 `clock.seek(next)`）后该用例立即失败（`expected 0 to be greater than 0`）。

### B. 暂停能力必须可用；过渡点用最新观测

- **PASS**。`pauseNativeAt` 现在返回布尔：页面没有原生命令入口时返回 false，**预览被拒绝**并写明"这个页面没有原生命令入口：无法暂停编辑区，拒绝接管时钟"（不再静默进入 review）。
- **PASS**。过渡点使用**最新**观测：描述/字节读完后再读一次 `nativeObservation.current`，用它暂停原生；读之前捕获的旧位置不再用于暂停。
- **PASS**。加载期间用户移动 → 不回卷：原生报告真的移动时，正在途的预览读取被作废（`closePreview`），编辑器**不会**被 seek 回旧位置（用例断言 `studioCommands` 不含旧时间的 seek）。
- **PASS**。scope/选区变化 → 作废在途预览：`target` 变化的 effect cleanup 会 abort 在途读取并作废 generation；`selectClip` 在有在途预览读取时也作废它。

### C. 读与写的围栏

- **PASS**。观察轮询**串行化**（在途未完成时不再发新轮询）+ 每读一个**序号**（只有最后发出的读可以落状态）：旧轮询不会覆盖新状态。
- **PASS**。`readReviewPackage` 现在有 generation、abort 与 **project/run/package 围栏**：回包必须仍属于所问的工程、运行与包；否则被丢弃。旧运行的迟到回包不会落到新运行上（用例：先挂起 run-1 的包读取 → 上下文换成 run-2 → run-2 的包先显示 → run-1 的迟到回包到达后画面仍是 package-2）。
- **PASS**。同 scope 乱序：轮询不重叠，结构上不可能乱序落状态（用例断言在途期间 20s 内的多次轮询没有发出第二次读，第一读结束后下一次轮询才再读一次）。
- **PASS**。同一 id 的**内容包更新**不再被 requestKey 压制：请求键现在带 `project_revision`/`workflow_revision`/`control_revision`/`selection_version`/run/gate/package，上下文版本一变就重读（用例断言同一 package id 被读了两次，版本从 1 变成 2）。
- **PASS**。旧决定不残留：包身份（run@package@version）变化时清空 `reviewDecision`；scope 变化时整块清空（用例：接受 → 运行切换 → "决定已登记"消失，画面是 package-2）。
- **PASS**。断连 → 预览停止、决定禁用：读取失败时 `connection=unknown`、`reviewStale=true`、预览被停止。

### D. 媒体事实与摘要

- **PASS**。**part.kind 与 media kind 必须一致**：preview→video、narration→audio、subtitles→text、shot_summary→json、rights_quality→json（CR-R1-001 §8 的读法；`shot_summary`/`rights_quality` 是否都为 json 见第 4 节的待确认项）。不一致即拒绝。
- **PASS**。**内容类型闭集**：video→`video/*`、audio→`audio/*`、text→`text/vtt|text/plain`、json→`application/json|…+json`；HTML 明确拒绝。
- **PASS**。**音频预览必须要求 `descriptor.timeline.fps` 与 clock 精确相等**（有理数相等，30/1 对 25/1 拒绝）；容差改为**一帧 = den/num 秒**（此前误用 1/num）。
- **PASS**。**package_digest 与真实包绑定**：不再只做正则检查。Host 把审阅包发布为产物，其产物 `Ref.sha256` 就是包文档的规范摘要，因此 app 用**上下文里该包自己的产物引用**与 `descriptor.package_digest` 比对（Host 的既有语义，不是 app 自造的比法）；上下文没有该引用时**失败关闭**（拒绝预览并说明"当前上下文没有它的产物引用"），不宣称"已完整绑定"。
- **PASS**。**download_ref 仍按冻结 schema 的 TOKEN**（`^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$` 或 null），未改成 URL；依 MAIN `msg_6bd5210f9a44` 与 CR-R1-002：**TOKEN 胜出**，绝不接受 URL、不放松 schema。

### 分页（CR-R1-002，MAIN 已批准）

- **PASS**。读入参**精确**为 `{project_id?, limit?, cursor?}`，无 filter/path/root/其他字段；`limit` 越界（<1 或 >64）或 `cursor` 不是字符串时客户端拒绝（`INVALID_PAGE_LIMIT` / `INVALID_CURSOR`），不发请求。第一页不带 cursor。
  - **已对照 canonical CR-R1-002 原文核过**（`/mnt/c/workSpace/videoWorkLine/Narralens/docs/execution/A/implementation-20261111/CR-R1-002-PUBLIC-PREVIEW-AND-QUERY.md` 第 17/19 行，父只读引入、本 lane 未修改该文件）："project_id 可省略；如存在必须为当前 delegate 项目的有效字符串；limit 可省略，为 1..64 整数，默认 32；cursor 可省略或 null，存在非 null 值必须为 opaque 字符串。除这三键外拒绝"；"410 须清空旧游标、说明失效并从第一页刷新，不自动把不同 generation 拼为全集。UI 应提供继续加载/下一页，第一页不能显示成完整库存。source-file 和 inventory 拥有各自游标，不可混用。"——与本实现逐条一致。
- **PASS**。候选清单与已登记清单**各自独立**的 cursor 与页数；"加载更多"按 Host 的 `cursor_next` 取下一页；出参 `cursor_next` 直接喂给下一次入参 `cursor`。
- **PASS**。**410 失效**：`cursor` 过期 → 丢弃该 cursor 与该代、**明确回到第一页**重读，并保留"已过期"提示；旧代的分页结果**不会**被拼成"完整清单"。
- **PASS**。**project/scope 变化**丢弃两个 cursor 与在途响应。
- **PASS**。**只显示第一页时必须明说**：面板写"当前只显示 Host 返回的第 N 页：还有更多候选没有显示，翻页由 Host 的受控游标决定"（候选与清单各一处），并提供"加载更多候选/加载更多已登记素材"。**不猜**未命名的游标入参——CR-R1-002 已给出精确名字，本轮据此实现。

## 2. 命令证据

cwd 全部为 `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT`；日志与元数据在 `docs/parallel/lane-product/A-R1-20261111/logs/`。

最终候选（接入公共模块之后）的证据：

| 日志 | argv | exit | log SHA256 |
| --- | --- | --- | --- |
| `app-final-tsc.log` | `corepack pnpm exec tsc --noEmit` | 0 | `087f869f50013fbb3d924db8895a16be5c1a253b127d8110a6ddbc77890848db` |
| `app-final-tests.log` | `corepack pnpm test tests/agent-driven/product/observation-ui.test.tsx tests/agent-driven/product/local-asset-registration.test.tsx tests/agent-driven/integration/created-workbench-review.test.ts --maxWorkers=1 --minWorkers=1` | 0 | `dd014208d86d43a9ced4c9b7e1d0557a26ed2aa98a89ad9576bac14a985d14fa` |
| `app-final-architecture-fitness.log` | `corepack pnpm test tests/architecture --maxWorkers=1 --minWorkers=1` | 1 | `aebd74a365abf686a8a17e65a99deb896cfb4f8ab5cf620d24a6f80ba035d868` |

轻量用例共 **108 通过**（63 + 13 + 32）。

（接入公共模块之前的同一批次证据另存：`app-round2-tsc.log` `a2eb1dc7…652b` exit 0、`app-round2-tests.log` `434bd155…7870` exit 0（105 通过）、`app-round2-architecture-fitness.log` `e092d039…ef76` exit 1。）

**首失败（如实）**：`tests/architecture/m2.2-fitness.test.ts` 2 个用例失败（`src/host/agent-driven/created-task-store.ts`、`src/host/projects/project-creation-store.ts` 越权写 job state）。这两处**不在**本票范围、本轮**未**触碰；MAIN 已在 `8ef4976` 修好基线但**未**集成到本 checkout，因此**本 checkout 仍不绿**，不宣称绿。

## 3. NOT_RUN

| 项目 | 原因 |
| --- | --- |
| `pnpm build` / `vite build --config vite.m5.config.ts` | MAIN：**尚无 build 槽**；队列在 appfix 与公共模块消费之后。app 首次引入冻结合同的 Ajv 校验器，**面板 bundle 体积变化仍未验证**。 |
| `created-native-ui-transport.test.ts` | 被 hold 的 MAIN 传输测试，不得运行。 |
| Host / listener / ffmpeg / Chromium / 媒体 / 全量 `pnpm check` | 需 MAIN 单槽预约，未获槽。 |
| 真实 Studio / 真实 Host / 真实准备媒体的端到端预览 | R1 尚无生产者接线（第 4 节），本轮只能给组件与客户端证据。 |

## 4. 真实 producer 依赖与待确认项

1. **公共 DTO 归属（MAIN 正在处理）**：MAIN 决定发布 `src/contracts/prepared-preview.ts`（权威的 descriptor/timeline/fact/receipt 类型 + 纯 max-read 常量），`assembly-ports` 再导出（冻结提交 `16c0c401f34116264f3515eee8af039333c9124b`）。本票**未**创建或编辑 `contracts/**`；app 侧现有的三个临时结构类型（`PreviewMediaDescriptorV1`/`PreparedPreviewTimelineV1`/`PreparedPreviewMediaFactsV1`）是**占位**，父方安全集成该模块后必须换成对它的 import（app 仍不得 import `src/host/**`）。**待办，随交接继续。**
2. **`context.read` 必须携带审阅包的产物引用**：app 用它作为 Host 的规范包摘要来绑定 `package_digest`；本 checkout 的 `context.read` 在 registry 里仍是 `production: NOT_IMPLEMENTED`，所以上下文里没有该引用时预览**失败关闭**。需要 BRIDGE/MAIN 让 context 暴露 `artifacts`。
3. **`shot_summary` / `rights_quality` 的 media kind**：CR-R1-001 §8 写"subtitles/shot_summary/rights_quality 的 media_facts.kind 分别 text/json"，三对二有歧义。本轮按 **subtitles→text、shot_summary→json、rights_quality→json** 实现（最自然的读法），并在代码注释中写明；**请 MAIN 确认**。若 Host 实现为 text，本轮这一处会变成"合法产品被拒"的失败关闭，需要按 MAIN 的裁定放宽。
4. **附属读取的运行时与 registry**：`local-assets.v1/*` 与 `workbench.v1/review.part.describe` 的实际 handler 与运行时 registry（`contracts/agent-workbench-ui-v1.registry.json`，BRIDGE 唯一编制）仍不在本 checkout，真实运行时这些组合是 503，app 如实显示"不可用"。
5. **未解决的既有红灯**：`m2.2-fitness` 的两处 Host 越权写（MAIN 在 `8ef4976` 已修，未集成到本 checkout）。

## 5. 进程与清理

未启动任何服务、listener、浏览器或后台进程；命令均为前台一次性 `tsc`/`pnpm test`。未安装、未联网、未读 J 盘、未付费、未外传素材、未改模型或供应商、未读 `~/.claude`/`~/.codex`/`.env`、未 dump env。未 `git push`、未合 main、未 `reset`/`stash` 用户工作。

## 6. 交回

写权在父方导入公共模块并**显式交回**后继续；本轮在此之前不再写文件/索引、不再运行测试。

## 7. 公共模块接入与最终候选（父方导入后）

- 父方按 `msg_1e8ad5ec7177` 只导入了新的 `src/contracts/prepared-preview.ts`（MAIN `16c0c401f34116264f3515eee8af039333c9124b`，本地 HEAD `7f4815c876e043821e154d5213697dd86831116a`，模块 SHA256 `7da67257dd016fa4aeff34ca418642467ec0a999b91d518eda0a507ebed8c6c0`，证据 `PUBLIC_PREVIEW_INTEGRATION.json`）；原 `assembly-ports` 未改，20 个原未跟踪票据文件哈希保留，index 干净。
- **临时结构类型已删除**：`src/app/agent-workbench-client.ts` 与 `src/app/m5/M5Panel.tsx` 现在从 `src/contracts/prepared-preview.js` 导入 `PreviewMediaDescriptorV1` / `PreparedPreviewTimelineV1` / `PreparedPreviewMediaFactsV1`；app 内不再有第二份协议定义，字段仍逐条校验（校验的是合同自己的形状）。**app 仍然不 import `src/host/**`**（`m2.1-fitness` fitness 1 保持绿）。
- 本轮**未**编辑公共模块、`assembly-ports`、Host 任何文件或被 hold 的 transport 测试（`git diff 7f4815c -- <上述路径>` 为空）。
- **最终 app 候选：`ed44a9b`**（`refactor(A-R1 PRODUCT): consume the public preview DTO module`），只含 3 个允许路径：`src/app/agent-workbench-client.ts`、`src/app/m5/M5Panel.tsx`、`tests/agent-driven/product/observation-ui.test.tsx`。未 push、未合 main。
- 本轮两笔提交：`e6c03a7`（播放/围栏/媒体事实/分页）与 `ed44a9b`（接入公共模块 + 分页边界补测）。
- 补测完成：清单游标过期回第一页、清单侧的 410、工程切换丢弃两个游标与两页、旧工程迟到的分页页不落到新工程。

### 仍未解决、仍需 MAIN/BRIDGE 接手的事实

1. **`context.read` 必须携带审阅包的产物引用**：app 用它绑定 `package_digest`（Host 的规范包摘要）。本 checkout 的 context 生产者仍是 `production: NOT_IMPLEMENTED`，因此真实运行时会**失败关闭**（拒绝预览并说明缺少产物引用），这与"缺失即不宣称已绑定"一致，但需要 BRIDGE 让 context 暴露 `artifacts` 才能真正预览。
2. **`shot_summary` / `rights_quality` 的 media kind**：本轮按 json 实现（CR §8 "分别text/json" 的读法），已写进代码注释，请 MAIN 裁定；若 Host 实现为 text，本轮这一处会变成"合法产品被拒"的失败关闭。
3. **附属读取与 `review.part.describe` 的运行时 handler / registry** 仍不在本 checkout，真实运行时这些组合是 503，app 如实显示不可用。
4. **`m2.2-fitness` 两处 Host 越权写 job state**：MAIN 已在 `8ef4976` 修好基线但**未**集成到本 checkout，因此**本 checkout 仍不绿**，不宣称绿。
5. **build 槽**：app 首次引入冻结合同的 Ajv 校验器（`src/contracts/agent-driven-validator.ts`），面板 bundle 体积变化**仍未验证**；MAIN 的队列在 appfix 与公共模块消费之后，本轮**未**获槽，未跑 build。
