# TRANSPORT_REWORK_HANDOFF —— A-R1-PRODUCT 传输阶段的原始证据映射

本文件只是一份**只读证据交接**。本次工作没有改任何源码、没有动索引、没有跑任何测试、没有启动任何子进程。
它记录传输阶段四次运行的原始失败、每次之间的确切改动，以及当前被冻结文件的字节与哈希。
MAIN 拥有该阶段的根因诊断与修复；本文件不提出修复方案，也不代替 MAIN 做判断。

身份：实际子 Task `task_ab60510a8f07`，Dispatch `ctx_c3539845af23`，终端 handle `term_b66f4ca773d213d434d380cd8b09b29c`；
父 Codex `term_dbe899889c960daeaba8b5f3ba7fe6e2`；MAIN `term_a731c232-35c7-4f55-a75d-9b2beeade398`。

## 1. HOLD 确认

对以下三个文件，本 lane **保持 HOLD**：不编辑、不测试、不导入、不执行。

| 文件 | df32311 字节 | 行 | SHA256 | git blob |
|---|---|---|---|---|
| `src/host/m5/controlled-studio-access.ts` | 22215 | 363 | `9f10ba2748a77a66d0537d0915f272c80ed0913ebbfb28a4aa647a22e5d89b70` | `029ff625d6a6e85160d977ab98a594672d2fb05b` |
| `src/host/m5/openfilm-studio-gateway.ts` | 55383 | 1086 | `8be50e04acaf0993f8f0b1c8cf917982ff455f3bff5f54a4cba16065c8d6865b` | `4df280388217c85b47942a23e9f7e752fb221819` |
| `tests/agent-driven/integration/created-native-ui-transport.test.ts` | 22242 | 550 | `64821d8052a81fabbbffcda8b4f9d2ad4d295ae22f71c41e6c6866a4dcdd3be7` | `6cbf3270feb8f2b03dbb04deda67ea0f6cb6ab20` |

工作区与 `df32311` 对这三个文件**完全一致**（`git diff df32311 -- <三文件>` 为空）。当前 HEAD 即 `df32311ce86193aa91db4535776d833358680013`。

> 注：`src/host/m5/openfilm-studio-browser.ts` 不在 HOLD 清单内，但本阶段也未再改动它（见 §4）。

## 2. 原始日志（未改写）

- `docs/parallel/lane-product/A-R1-20261111/logs/created-native-ui-transport.test.log`，29447 字节，SHA256 `805d5ba727e94cedfd52897c110b8bc1d1fa94c98f4a1854ba2724ae034bd837`。
  它按顺序包含**全部四次**运行（run 1 的原始失败在最前，run 4 的通过在最后），中间没有任何删改或重排。
- `docs/parallel/lane-product/A-R1-20261111/logs/tsc-transport-test.log`，SHA256 `ed00e856d51d068e4e64c11856ec94a0cf65c7be3407f6882acb63c4d6f9efad`（传输测试加入后、最早一次 `tsc` 的两次结果：exit 2 与修复后 exit 0）。

四次运行同一条 argv、同一个 cwd、同一个 HEAD：

```
argv:  corepack pnpm test tests/agent-driven/integration/created-native-ui-transport.test.ts --maxWorkers=1 --minWorkers=1
cwd:   /home/administrator/orca/workspaces/Narralens/Narralens-A-R1-PRODUCT
head:  535ad0c003ede9be258044809a002cdf33ad53d3     （四次全部相同）
slot:  R1-PRODUCT-TRANSPORT-001
```

| run | 行区间 | shell_pid | start | end | exit | 结果 |
|---|---|---|---|---|---|---|
| 1 | 1–330 | 767019 | 22:09:45 | 22:09:47 | 1 | Test Files 1 failed；**Tests 20 failed / 1 passed (21)** |
| 2 | 331–415 | 767497 | 22:10:03 | 22:10:04 | 1 | **Tests 2 failed / 19 passed (21)** |
| 3 | 416–483 | 768164 | 22:10:21 | 22:10:23 | 1 | **Tests 1 failed / 20 passed (21)** |
| 4 | 484–506 | 768624 | 22:10:40 | 22:10:41 | 0 | **Tests 21 passed (21)**，Duration 999ms |

## 3. 原始失败映射（逐条，取自日志原文）

### run 1 —— exit 1，20 failed / 1 passed

唯一通过的是 `the two workbench UI aliases > adds exactly two Gateway aliases and states the exposure count`。

- **19 个用例**同一失败：`AssertionError: expected undefined to be defined`，断言点是
  `tests/.../created-native-ui-transport.test.ts:100:20`，日志保留了当时的源码摘录：

  ```
  98|     const native = cookies.find((value) => value.startsWith("narralens…
  99|     const uiCookie = cookies.find((value) => value.startsWith("narrale…
  100|     expect(native).toBeDefined();
  ```

  即：夹具按 `startsWith("narralens_native_=")` 找 cookie，但 cookie **名**带随机后缀（`narralens_native_<hex>`），
  `=` 在后缀之后，所以永远匹配不到。属于**夹具断言写错**，不是生产行为问题。
- **1 个用例**不同失败：`the independent UI credential > mints nothing when the parent is already revoked`
  → `Error: The controlled native session is unavailable`，栈为
  `ControlledStudioAccess.#alive (src/host/m5/controlled-studio-access.ts:164) ← issue ← OpenFilmStudioGateway.issueNativeEntry`。
  原因：用例把 **native grant** 置为 revoked 再去 `issue()`，而 `issue()` 对 revoked grant 本身就抛 `NATIVE_SESSION_STALE`，
  根本走不到兑换。属于**用例前提写错**（要测的是"不发 UI 凭据"，不是"不发 native 入口"）。

### run 2 —— exit 1，2 failed / 19 passed

- `mints a separate cookie and proof for a grant that carries a UI delegate`：
  `AssertionError: expected 'narralens_ui_d6b27c9d3d2b6987178907b3=CljNyykDs6U5ISlweJytarnl9wDHJ9YNqNTVd04TsEs' to contain 'narralens_ui_='`，
  断言点 `:206:32`，源码摘录 `expect(session.uiCookie).toContain("narralens_ui_=");`。仍是**同一个 cookie 名后缀问题的残留断言**。
- `refuses a duplicated UI proof header`：`AssertionError: expected 401 to be 403`，断言点 `:248:31`。
  用例用 `fetch` 传两个同名头；`fetch` 的 Headers 会把重复头合并成一个值，Gateway 因此按"只有一个证明头、但证明值不匹配"处理而回 401，
  没有走到重复头检查。属于**用例手段不成立**。

### run 3 —— exit 1，1 failed / 20 passed

- `refuses a duplicated UI proof header`：`AssertionError: expected 400 to be 403`，断言点 `:247:29`，
  源码摘录显示此时用例已改用 `node:http` 的原始客户端发请求。
  400 来自 Gateway 的 `INVALID_REQUEST`；即该请求**没有把两条同名头作为两条真实头行送到 Gateway**，
  重复头检查没有被触发。**这一 400 的确切成因当时没有再往下隔离**（没有保留中间字节可供复查，见 §5），
  当时采取的处置是换一个真正按字节写请求的客户端，而不是去改生产 guard。

### run 4 —— exit 0，21 / 21 passed

重复头改为用 `node:net` 原始 socket 逐字节写请求后，Gateway 收到两条真实头行，
`#headers()` 的重复头检查返回 **403 `ORIGIN_REJECTED`**，用例通过；其余 20 例保持通过。

## 4. 四次之间**确切**改了什么

**运行时的代码状态（重要，避免误读）**：四次运行的 HEAD 都是 `535ad0c`，但**工作区**里已经包含尚未提交的实现改动——
两条 Gateway 别名与闭集校验、父 Codex 要求的三处接缝修正（打开后复检失败先 close 再抛、`mintUi` 验活 parent 且 map 有界、
单次读 1MiB 而请求区间可更大）、`StudioAccessError` 增加 `'RANGE_NOT_SATISFIABLE'`、以及 Gateway 依赖
`uiRegistry: GatewayUiRuntimeRegistry | null | undefined` 的放宽。这些改动随后一起进入 `df32311`。

下表只写**四次之间**的改动：那是**纯测试夹具/断言**的改动，四次之间**没有改过任何生产代码**——
`src/host/m5/controlled-studio-access.ts` 与 `src/host/m5/openfilm-studio-gateway.ts` 在 run 1 到 run 4 之间字节未变。

| 区间 | 改动（测试文件内） | 依据 |
|---|---|---|
| run 1 → run 2 | ① cookie 选取从 `startsWith("narralens_native_=")` / `startsWith("narralens_ui_=")` 改为正则 `/^narralens_native_[0-9a-f]+=/` / `/^narralens_ui_[0-9a-f]+=/`；② 文件末尾新增 `readSetCookies(response)` 辅助函数（优先 `headers.getSetCookie()`，否则回退到 `headers.get("set-cookie")`）；③ 用例 `mints nothing when the parent is already revoked` 的前提从"revoked **native** grant"改为"live native grant + revoked **UI delegate**（`fixtureUi(recorder, () => false)`）"，并补一条断言：native-only 入口调 UI 必须 401 | run 2 的失败点（`:206`、`:248`）与 run 1 的失败点（`:100`） |
| run 2 → run 3 | ① cookie 名断言从 `toContain("narralens_ui_=")` 改为 `toMatch(/^narralens_ui_[0-9a-f]+=/)`；② 重复头用例从 `fetch` 改为 `node:http` 客户端：新增 `rawPost(origin, path, headers, body)`，其中 `headers` 为**扁平数组**（`['Origin', v, 'Content-Type', v, ...]`），并把 `import {request as httpRequest} from 'node:http'` 加入文件头 | run 3 的失败点（`:247`，已显示为 `node:http` 版本） |
| run 3 → run 4 | `rawPost` 由 `node:http` 改为 `node:net` 原始 socket：新增 `connect`/`Socket` 导入，自行拼装 `POST <path> HTTP/1.1`、`Host`、`Content-Length`、`Connection: close` 并逐字节写出；响应按 `\r\n\r\n` 切分取状态行与 body；重复头用例的 header 行改为**两条独立的 `X-Narralens-Workbench-CSRF:` 行** | run 4 通过（403） |

补充事实：

- 四次运行的 HEAD 都是 `535ad0c003ede9be258044809a002cdf33ad53d3`；四次之间**没有**提交（`git log` 中该区间只有这一个提交），
  因此这些改动只存在于工作区。
- 四次运行的工作区里已经存在的生产改动（相对 `535ad0c` 的差异见 `git diff 535ad0c df32311`）：
  `controlled-studio-access.ts` 的 `StudioAccessError` code 联合加 `'RANGE_NOT_SATISFIABLE'`、
  `openUiMedia` 的"整体 ≤1MiB"改为"单次读 ≤1MiB（区间可更大）"、`mintUi` 增加 parent 验活与 UI map 上界、
  打开后复检失败先 `close()` 再抛；`openfilm-studio-gateway.ts` 的两条别名、闭集 registry 校验、
  `uiRegistry` 依赖类型放宽为 `GatewayUiRuntimeRegistry | null | undefined`（`null` 明确表示"没有 registry"，便于确定性地触发 503 分支）。
  这些都发生在四次运行**之前**，与测试失败无关，且在四次之间**未再变动**；它们最终都在 `df32311` 内。

## 5. 中间字节**没有**被保留（如实说明）

run 1、run 2、run 3 三个中间版本**测试文件的确切字节没有被保留**，无法复原，也没有试图复原：

- 这三个版本从未进入任何提交（`git log` 无对应 commit），未 stash（`git stash list` 为空），
  也没有以其他分支/标签留存。
- `git fsck --lost-found` 只发现三个与本阶段无关的悬空对象：
  一个 MEDIA 提交 `4fc69c2e…`、一个早期 migration 提交 `ee58484a…`、一个旧文档 blob `7df8d22a…`；
  **没有任何一个包含本测试文件的中间版本**。（本次 fsck 未产生 `lost-found` 目录，未留下仓库副作用。）
- 因此 §4 表格中的"确切改动"是**依据日志中保留的失败点源码摘录与断言原文**复原的语义与文本改动，
  而不是三个中间文件的逐字节 diff。日志保留的源码摘录（run 1 的 `:98–102`、run 2 的 `:204–208` 与 `:246–250`、
  run 3 的 `:245–249`）是这些版本里**唯一逐字保留下来**的片段。
- run 3 那个 400 的确切成因**没有被隔离到根因**：当时的处置是换客户端，而不是继续追查 `node:http` 那条请求的实际报文。
  若 MAIN 需要该请求的真实报文，只能重跑复现——那需要新的 MAIN 槽与 HOLD 解除。

## 6. 与 MAIN 已发现缺陷相关的**当前**代码位置（只读指引，未改）

以下行号取自 `df32311`，供 MAIN 的根因诊断直接定位；本 lane 不做任何修复。

- `src/host/m5/openfilm-studio-gateway.ts`
  - `#uiCall` 位于 499 行；`invokeUi` 的 await 在 522 行，随后 524 行写响应。
    访问层在 await 前后各有一次复检（`controlled-studio-access.ts` 280 行与 292 行），**调用**路径是有复检的。
  - `#uiReviewMedia` 位于 535 行：先 `openUiMedia`，再 `readBounded`（556 行），再 `response.writeHead`（552/560 行），最后在 `finally` 关闭 reader（563 行）。
  - **await 读之后、写响应之前没有复检**：最后一次 `media.read()` 之后到 560 行写响应之间，会话可能已被撤销而字节仍会写出。
  - **没有 abort 生命周期**：`readBounded` 里的 `media.read({offset,length})`（1079 行）没有传任何 signal；客户端断开也不会取消读。
  - **整对象缓冲**：`readBounded`（1069 行）把分段读到的块全部 `Buffer.concat(chunks)`（1085 行）后才一次性写出。
- `src/host/m5/controlled-studio-access.ts`
  - `openUiMedia` 306 行：await `openReviewMedia`（312 行）后复检（313 行），复检失败会先 `close()` 再抛（314 行）——
    这一段是有关闭保证的；**读阶段**没有对应的复检或取消。
  - `openReviewMedia` 的入参类型里**没有 signal 字段**；父 Codex 已说明"可选 `openReviewMedia.signal` 属 MAIN 的内部修正，不改 HTTP DTO"。

## 7. 写权与停止状态

- 本 lane 的最后一次实现提交是 `df32311ce86193aa91db4535776d833358680013`（仅 16 个释放产品路径）。
- 索引**干净**（`git diff --cached` 为空）；工作区只有本票文档目录为未跟踪。
- 本次证据任务期间：**没有**写源码、**没有**动索引、**没有**跑测试或任何服务、**没有**启动子进程。
- 进程状态：没有属于本 lane 的 vitest / narralens 进程；四个记录在案的 shell PID（767019、767497、768164、768624）均已退出；
  没有属主进程已死亡的监听 socket。
- 清理证据的**限制**（沿用前次记录，不因本次而改变）：每个用例的 Gateway 端口号**未逐例记录**（`port: 0`，OS 分配），
  因此**没有端口级核对**；"有属主的监听"不能证明我方无残留，不能当作该证明。实际证据是：记录的 shell PID 已退出、
  每个用例在 `finally` 里 `gateway.close()`、事后无本 lane 进程。
- **写权**：本 lane 对三个 HOLD 文件的写权与测试权**已停止并释放**给父 Codex / MAIN；本 lane 在 MAIN 明确解除 HOLD 并另行授权前，
  不会编辑或运行这三个文件。

## 8. 明确不声称

- 不声称传输阶段的问题已被诊断或修复；根因与修复由 MAIN 决定。
- 不声称 run 4 的 21/21 等于真实 Studio / 真实 Host 应用集成：那是**组件传输证据**（stub Studio + 临时 loopback Gateway），
  也不是 A 验收。
- 不声称 §4 的改动是逐字节复原；中间字节未保留这一事实已如实写明。
- 本 lane 未自签独立审查或人工验收。
