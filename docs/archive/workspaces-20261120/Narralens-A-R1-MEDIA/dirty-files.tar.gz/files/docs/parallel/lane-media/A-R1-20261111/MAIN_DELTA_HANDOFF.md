# MEDIA R1 frozen delta for MAIN rework3

Base `84deba07927fa59b45a24039b4740a2f9d3fd430` → candidate `c8a06729c2a58d0e79c40042f3155c558ca6fd11`. Exact blob/byte/SHA256 manifest: MAIN_DELTA_MANIFEST.json. Six changed files within twelve released paths; other six unchanged. No dependency helper or package/lock changes to import. Consume the exact six-file tree delta against base (or all seven listed chronological lane commits), not only the last follow-up commit. Cross-lane integration remains MAIN-owned.

Changed files: created-draft-processor.ts, prepared-draft-verifier.ts, assembly-ports.ts, new preview-prepared-source.ts; created-draft-processor.test.ts and new preview-prepared-source.test.ts. Manifest includes exact path names and direct helper/pin dependencies, all remaining dependencies inherited from common base. Untracked ticket logs/docs are evidence, not source commits; do not copy writable DB/node_modules/var/dist/profile.

Real helper created-project-fixture.ts starts NarralensHost/CreationApplication on ephemeral port/SQLite and bootstraps through fixture HTTP auth using cp-a0 contract-vectors. Processor tests also use TestAdoptionAuthority and explicit eligibility/capability fixture facts: diagnostic component evidence, not production authorization or A real human media. Preview fixture constructs TaskReservation/completion itself with literal run/job/baseline values and an empty author-rights callback; it is not real production prepare/Host completion lineage. Its comment saying nothing stands in for Host is too broad. MAIN should inspect this along with missing metadata and failing fixture cleanup; no second production producer is established merely by this fixture. No recommendation to extract a helper before MAIN root-cause decision.

Both tests use read-only pinned vendor at /mnt/c/workspace/videoworkline/Narralens-openfilm-m1b/vendor/openfilm. Synthetic ffmpeg color/sine inputs are generated per isolated temp fixture; no prebuilt fixture/media tree needs transfer. Preview never reached renderer in failed run. Original failure log and cleanup evidence stay in this ticket; no heavy rerun, no source/index modifications during this manifest preparation.

Parent task task_0b49b1b287cb / ctx_555dcbf15135; stopped child task_02dd86ffb3f7 / ctx_0c5994b7463b. MAIN takeover message msg_afb9335398ba governs current writer. This is not completion or independent PASS.


## MAIN rework3生产缺陷补充（2026-11-11）

来源：MAIN消息msg_d8c031cb7e0b；MAIN在其集成目录只读诊断后实施修正，MEDIA本地仍冻结c8a06729c2a58d0e79c40042f3155c558ca6fd11，无本lane源码/测试/索引改动。

MAIN确认preview生产probeVideo将实际PTS秒差与expected.num/expected.den比较，30fps因此错误要求30秒帧间隔；正确应为expected.den/expected.num，即1/30秒。原四项测试在缺metadata的fixture处失败，隐藏了此生产缺陷，不能将那次fixture失败解释为已交代码正确。MAIN已报告在集成目录修正倒数，并在复用真实processor的preview测试增加rights_quality实际解码时间间隔断言；本lane未运行或独立验证该修正，不签PASS。

MAIN先前msg_62fd132e4e83的fixture修复使用实际CreatedDraftTaskProcessor/CreatedTaskStore/worker、真实持久job/provider receipt/fact与原私有metadata路径，形成测试共享helper而非第二生产metadata writer；原三镜计划为90frames/144000 audio samples，断言绑定真实计划。fixture eligibility/TestAdoptionAuthority仍为组件测试端口，合成媒体不是A真实人声影片证据。

原R1-MEDIA-PREVIEW-002 exit1、7PASS/4fixtureFAIL、原candidate及日志/清理记录全部保留。其他proof/reader/lifecycle由MAIN继续审核，生产预览仍未证实；MEDIA与Claude保持source/test/index停写，无额外重试/重型命令。此前CLAUDE“缺陷只在fixture”的说法是被本节纠正的历史作者判断。
