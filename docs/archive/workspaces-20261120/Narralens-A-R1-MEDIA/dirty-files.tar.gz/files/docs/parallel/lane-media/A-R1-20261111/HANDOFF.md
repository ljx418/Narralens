# CURRENT EXECUTION — RELEASED 2026-11-11

此节覆盖下面所有历史NOT_RELEASED、旧base、凭据等待及需MAIN再批准429接管的描述。MAIN_START.md及当前ReleaseAssignment为准，不重审整包。

父任务task_0b49b1b287cb / dispatch ctx_555dcbf15135；MEDIA Codex term_56c18dc666859e62a33170c02d113469；MAIN term_a731c232-35c7-4f55-a75d-9b2beeade398。实际checkout `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-MEDIA`，base `84deba07927fa59b45a24039b4740a2f9d3fd430`，contract `ca5b67a8285b130c79055317c6202f73cfbb99c8`，R0源码freeze9f583239714835a89332fcae9363aa39d887821d；src/tests/contracts/tools/package/lock diff实测为空。Assignment SHA256 `ff7b0a6419590f069f7c2a81e1bf757c3cb0c9c86c48053e91c8d1924e275350`，interface `7e9b61b339d9cf2bc80c7925e09139f6362eeee6ecc373a2bd142d4be0f895b8`，registry `8416e1abeec71b4e063df53c9e4974ea4ab1bab3b8f1f5ddfc280f5b5261e54f`匹配。全局127唯一owner，R1为BRIDGE55/PRODUCT23/MEDIA12，MEDIA不得写其他owner。

当前用户明确授权既有ClaudeCode研发CLI；事件处置UNKNOWN，不读~/.claude/~/.codex/.env、配置、凭据、敏感日志或全量env，不切供应商/model，不新增产品付费或外传。后续限制优先。当前票据准备writer=Codex；本节完成后在此checkout启动唯一keep-open Claude，输入实际送达后writer=Claude，Codex仅只读。由Claude将自身真实task/dispatch/handle写入HANDOFF追加节，记录父子关系与启动接受事实；不要把计划handle当实际。Codex不在子writer活动时编辑任何文件/index/运行根。

精确允许产品路径（12）：

- `src/host/agent-driven/created-draft-processor.ts`
- `src/host/agent-driven/prepared-draft-verifier.ts`
- `src/host/engine/source-digest-v1.ts`
- `src/host/render/assembly-ports.ts`
- `src/host/render/native-draft-assembler.ts`
- `src/host/render/native-draft-io.ts`
- `src/host/render/native-draft-plan.ts`
- `src/host/render/preview-prepared-source.ts`
- `tests/agent-driven/integration/created-draft-processor.test.ts`
- `tests/agent-driven/integration/source-digest-resource-boundary.test.ts`
- `tests/agent-driven/media/native-draft.test.ts`
- `tests/agent-driven/media/preview-prepared-source.test.ts`

文档/日志/证据仅本票前缀。保留未提交TASK/HANDOFF/CLAUDE_IMPLEMENT/MAIN_START/ReleaseAssignment，不stage这些用户/MAIN输入；源码只显式add本票实际路径，不push/merge/reset/stash。新日志记录cwd/argv/time/exit及SHA256、case、PID/后代和清理，禁止覆盖旧历史捕获。

实施顺序：
1. 先在assembly-ports.ts新增已锁CompletedPreparedSourceV1、PreparedReadBindingV1/PreparedAdoptionBindingV1、PreparedPreviewRequestV1/ReceiptV1、PreparedReviewMediaReader及metadata/descriptor所需共享类型；命名/字段逐项遵CR1–8，旧调用兼容。必要时只读引用现有类型，不重复协议。运行corepack pnpm exec tsc --noEmit（轻量获准），显式仅提交该类型文件作为早期类型候选，记录完整commit/导出字段与编译结果，立即向父Codex和MAIN报告该候选；随后继续本票实现，不等额外审批。
2. 保留现prove/proveExisting/assertCurrent lease路径；新增目的区分的read/adoption FD proof与同步assert，按CR5完成事实与当前author/rights重验，不claim成功Job、不接受JSON或错purpose proof。
3. 实现隔离PreviewPreparedSource与五part真实receipt，CR8真实probe/decode fps/count及audio样本事实进入digest，独立对象FD reader，受控describe metadata由BRIDGE消费；不写author、不伪SnapshotClosure、不做committed encode/Delivery。现有renderer只读复用，不改本票外文件。缺真实能力保持不可用，不能生产注入测试替身。
4. 在已允许processor测试把新诊断输出从旧docs/execution/A/logs转本票私有logs/evidence，再运行该测试。M01/M02/M07/M16/M17及CR8负向按原TASK，所有未运行如实NOT_RUN。类型/纯单元可轻量运行；Host/ffmpeg/Chromium/大fixture/build/full必须先向父Codex申请MAIN全机重型槽，未获实际slot不可运行。Headless静音，maxWorkers=1；不安装、不新建共享可写运行根。MAIN通知离线独立依赖已准备，不需再安装。
5. 消费其他lane新export时提出具体producer commit需求，不重定义协议；仅阻塞依赖动作，其余连续完成。跨分支集成MAIN协调且必须writer安全停点。实现收尾显式提交本票代码/测试，报告全SHA、dirty、diff、自测/失败与真实consumer未接部分；组件证据不签A/人验/独立审查。

完整已审基础提示词在本文后部原文保留；R1只source-only/read/adoption proof/preview，原全A prompt的committed phases/Delivery/T20后续任务不在本票实现。MAIN_START、committed CR1–8、interface-decision.json、AUTHORIZATION_INTERPRETATION.md均必读，架构已定无需Claude裁决。

429：Claude记录错误并停止本任务写入/命令，向父Codex报告所有dirty与自有进程；MAIN已预授权Codex仅在证原调用及全部子进程停止、保全HEAD/dirty/日志并记录唯一writer移交后接管，无需再次问用户。不能凭超时/429单行推定停止；Claude恢复不自动抢回。超过两次返工报MAIN共同根因，不机械重试。不开子worker、不进B。


---

# A-R1-MEDIA HANDOFF

2026-11-11；本次task_53b31efc815b / ctx_51ef3a281194已完成有界preflight，IMPLEMENTATION_NOT_STARTED，PREFLIGHT_COMPLETE_WITH_INTERFACE_ACTIONS，不是产品验收。MAIN终端term_a731c232-35c7-4f55-a75d-9b2beeade398；本Codex term_4513c300-1424-43ab-bef2-6017ce3055b7，run_399f9dd3ce5a。

- 实际目录：`/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-MEDIA`。
- base/HEAD：`9f583239714835a89332fcae9363aa39d887821d`；contract：`ca5b67a8285b130c79055317c6202f73cfbb99c8`，文档freeze commit `f0c4f4f34fb1b81cf1ea0e0af2fd22a9eab38450`。
- 当前writer：MEDIA Codex，仅三文档；计划implementation writer=media-Claude，未启动/未调用/未移交，不复用历史Claude handle或dispatch。用户可见Codex窗口保留。
- 初始dirty仅MAIN的ReleaseAssignment.json；结束预期dirty为该文件加本次TASK/HANDOFF/CLAUDE_IMPLEMENT，全部untracked；无tracked产品差异、无index/branch/commit操作。
- ReleaseAssignment原字节hash `dbca1ce94ec80aa32d1da30fda748c2ff41428189d64b911912e5e1cd2bf2ba9`，status PREPARED_NOT_RELEASED，未改。
- preparation manifest `2a847488f59259b196caeb22e0407327583fed6985516ed16fa9bf9a87aad0c0`匹配；四冻结合同4/4及R0当前输入13/13 hash匹配（精确值见TASK）。这只验证绑定，不是复跑R0独立审查。MAIN已有R0范围PASS、tsc/123tests/10vectors如TASK引述；R0-M01仍归BRIDGE生产注册前修。

## 完成与实际命令

完成现地git rev-parse HEAD、git status --short --untracked-files=all、文档/接口/测试脚本只读检查，Python标准库sha256重算合同/manifest/13输入与03 owner交集，三文档编写；shell/Python文档操作exit0。使用orca-cli及orchestration技能读取实时CLI说明，不启动workers。没有产品测试、build、Host、browser、media、包安装或provider调用；无新业务进程/PID/媒体产物/测试日志。工具链运行版本未测，运行根和依赖由MAIN准备；不以package要求冒充实际可用。

拟实施12文件（10 existing+2 new、8源码4测试）逐项见TASK；最小预计5触点，其余只按实际必要性使用。完整审定implementation-prompts/media.md作为CLAUDE_IMPLEMENT原文基底保留，R1排除committed encode/Delivery，不缩水后续A要求。

## 需MAIN接线决定/下一步

I1：pre-impact只读复证与完整transaction/approval adoption proof的调用分工；不传假ID或成功Job lease。I2：preview receipt/read handle导出类型、BRIDGE opaque ref注册和FD关闭责任（含五part与package hash绑定）。详见TASK给出的具体建议；D01–D15仍ACK，不重新发起总体设计审核，不要求未来R2–R4先实现。

等待MAIN正式release、上述具体producer/consumer约定、凭据事件处置与显式writer handoff，之后才管理同目录MiniMax Claude实施。不得读取~/.claude、~/.codex、.env或dump环境确认供应商。MAIN安排依赖和重型单槽；现有processor测试会写历史docs/execution/A/logs，先在允许测试内迁移输出到获准私有根。后续M01/M02/M07/M16/M17和TASK命令全部NOT_RUN；BRIDGE同DB事务/HTTP、PRODUCT播放器、MAIN阶段组合/人验另由实际执行证据判断。

## writer移交和失败恢复

当前没有本dispatch Claude进程需要接管，不能据此推断历史会话均已停止。将来记录真实启动handle/task/dispatch、PID+start/子进程归属、命令和dirty；429先证原调用/后代停止再移交，不能凭日志或超时认定退出，须MAIN明确handoff才由Codex实现；保留所有内容。超过两次返工由MAIN接共同根因。实现者自测不是独立审查；实现SHA目前无，未签产品/独立/人验PASS，无B。

文档回退仅修正本票三文件，保留MAIN Assignment和封存包。后续回退不覆盖author/已提交snapshot/旧Gate，不删原prepared，未知写入进程存在时不清理其副本。

## 本次交付摘要

TASK.md SHA256 `a6ae714d82f249520899e6f9e43a4897e5435a4c0a72fda5bdaac7be4d21aa33`。
CLAUDE_IMPLEMENT.md SHA256 `20c89b7f76b3bd8e578ed8e80067fc29f5e3d9063029635241cb6cce0a55fad4`。
HANDOFF自身hash由最终终端只读校验输出，避免自引用。未新增独立evidence/log文件（超出本dispatch三文件权限）。


## CR-R1-001有界接口复核（2026-11-11，覆盖此前I1/I2待选择记录）

当前task_471be68020ee / dispatch ctx_0e80cd5e9454，Codex handle term_83ef49d9d2eba905bd1c62ac57984446。实际HEAD仍9f583239714835a89332fcae9363aa39d887821d；本dispatch仅追加TASK/HANDOFF，其他原有untracked文档保留。读取MAIN canonical实际三文件：

- canonical `/mnt/c/workspace/videoworkline/Narralens/docs/execution/A/implementation-20261111/CR-R1-001-INTERFACE-LOCK.md` SHA256 `a5694b60e86b07ba05495625310bdac18c6cdc30315e0bd4e4b046a570e42a1b`。
- canonical `/mnt/c/workspace/videoworkline/Narralens/docs/execution/A/implementation-20261111/contracts/gateway-ui.registry.json` SHA256 `40af12a3bd4a6b0a2dba4aee7a4d4092b155a2352bf9b2fb790a34c8eab7d765`。
- canonical `/mnt/c/workspace/videoworkline/Narralens/docs/execution/A/implementation-20261111/ownership-delta.json` SHA256 `8027fb4fd83eab107c140a7aea3e5a8c803c8e31a5898d4fdd82040f62367d06`。

结论：核心接口ACK；有一个精确字段反例需MAIN补齐，不重启总体设计/独立产品审查。原I1由CompletedPreparedSourceV1 + purpose=impact|preview的prove/assertCurrentForRead与完整adoption binding的prove/assertCurrentForAdoption明确关闭：前者不造transaction/approval，后者不得收read proof或旧TaskLease，成功SOURCE_ONLY不重新claim；BRIDGE提供真实同库身份和同步author/rights/Run/批准重验，MEDIA仅持有文件proof并release/close。原I2的producer/consumer及FD归属关闭：MEDIA immutable receipt先于package且无反向hash引用，BRIDGE登记真实包/part/input/output/quality/attempt映射；reader.open仅Host receipt+object_id，固定对象域/同FD核hash，有界read≤1MiB，MEDIA开失败释放，BRIDGE每响应正常/断流/取消/416/error finally幂等close。读不渲染、不交付、不写author。

独立UI delegate只由真实Host trusted_ui创建，独立cookie/CSRF与parent/generation/owner检查，native-only/driver/native proof不获批准权；commit后有效UI可读新Context而native仍stale。closed registry、原DTO与错误语义保持，native.reopen严格workbench.v1+空input、同既有native-open服务；31冻结Host+5附属Host+2新Gateway分别计数。四新owner路径与既有gateway归属均清楚，MEDIA仍12文件，无越owner修改。

唯一具体反例 CR-R1-MEDIA-FPS：第4节要求“预览receipt真实fps与项目clock匹配”，但第6节PreparedPreviewReceiptV1列出的字段及reader返回仅content_type/bytes/sha256，没有fps或已登记fps的消费者入口；冻结ReviewPart也无fps。实际M5Panel.tsx:160创建30/1 PlaybackClock，assembly-ports.ts的StagedNativeDraft有真实fps和frame_count，NativeRenderRequest亦需fps；PRODUCT若仅拿受控MP4字节/ref和当前明列receipt结构，就只能猜30/1或拒绝所有预览，不能据已有元数据完成要求的匹配。请MAIN在本Host-only receipt明确增加verified fps {num,den}（及frame_count用于帧边界），从已证native计划及实际编码参数一致性取得、纳入receipt_digest，并明确经受控part元数据供PRODUCT读取；不能改冻结ReviewPart/凭空从项目默认值复制。若MAIN已有另一条受控fps读取路径，请锁定具体producer/consumer字段即可，无须扩大本票文件。这个缺口只影响严格port字段闭合，不反对单clock方案、不要求R2/R3/R4先实现。

原M5 proxyRefs/现有视频区单活动槽、共用clock且review不seek/select author、进入按已观察frame用既有seek暂停、退出/切换/卸载精确abort/revoke/停播与单音频焦点均ACK；真实Headless联调未运行，不能按mock签通过。后续M02/M16增加fps不匹配明确拒绝且不改clock的断言，M17验证read proof不能apply；其他反例沿MAIN第7节，无新独立审查门。

依赖离线准备3/3成功且package/lock未变为MAIN本次通知，MEDIA未重复安装或自证运行结果。Claude调用、正式release/writer handoff仍未发生；产品/测试/重型检查全部NOT_RUN；R0仅scope freeze，无B。

本次追加后的TASK SHA256 `34cef9ae90a1be327c131235e568a457a60a1bfe520f633ef2eab0b9f2b4ef63`；上文旧TASK hash保留为前次交付历史，CLAUDE_IMPLEMENT与ReleaseAssignment未修改。


## CR-R1-MEDIA-FPS最终闭环ACK（2026-11-11）

本次task_50fc302096b7 / ctx_e5ca0d39282f，Codex handle term_33eca251294dfb46dc166222fc947a9b。仅读取canonical CR-R1-001第8节和gateway registry及MAIN更新的本地Assignment，并追加TASK/HANDOFF；不扩大审查范围。

**ACK：CR-R1-MEDIA-FPS字段缺口已关闭，本领域此项无剩余反例。** 第8节明确receipt顶层timeline fps/frame_count与video实际probe有理fps及完整decode/count帧数相符，规范化后纳入receipt_digest，不以项目默认值冒充探测；audio用真实sample_rate/sample_count/channels验证旁白范围，text/json保持判别类型。MEDIA reader metadata、固定receipt/object hash与BRIDGE包/part关联形成同一事实链，metadata打开也finally close。

既有RPC闭集新增workbench.v1/review.part.describe，严格输入run_id/package_id/package_version/part_kind/artifact_ref，project来自独立delegate；精确PreviewMediaDescriptorV1提供timeline/media_facts及package/receipt/object/bytes/hash绑定。PRODUCT据此先核真实fps与现有clock，再核下载ETag/hash/bytes，旧包或metadata到bytes间对象变化拒绝；25fps对30/1、伪报fps、缺事实、音频错误样本时长和FD关闭负向均已有明确断言，失败不改原clock/author/版本。无第三HTTP、无冻结ReviewPart/CP31修改，前轮其他ACK保持。

当前完整HEAD `9f583239714835a89332fcae9363aa39d887821d`；contract `ca5b67a8285b130c79055317c6202f73cfbb99c8`。本地Assignment仍PREPARED_NOT_RELEASED，MEDIA精确12文件不扩展。现测Assignment SHA256 `1ade994ceda67b7353c40fc2aea533d4c805edce3df954a93b4649b79c57ea12`；interface SHA256 `7e9b61b339d9cf2bc80c7925e09139f6362eeee6ecc373a2bd142d4be0f895b8`、gateway registry SHA256 `8416e1abeec71b4e063df53c9e4974ea4ab1bab3b8f1f5ddfc280f5b5261e54f`均与canonical当前字节匹配。旧Assignment/hash与前轮缺口记录保留为真实历史，由本节覆盖当前结论；不改封存包或CLAUDE_IMPLEMENT。

本次是具体R1字段/port闭合ACK，不是实现、测试、独立产品审查或人验PASS；未调用Claude、创建children、写代码或运行重型检查，未改Git索引/分支。后续仅待MAIN正式release、凭据处置和唯一writer移交，Claude无需另作架构决策；R0仍scope-only，无B。


## MEDIA Claude 实施记录（2026-11-11，RELEASED 实施窗口）

本节由实际承接实施的 Claude（media-Claude）追加，记录真实身份、当前 writer、命令证据与逐 case 结论。前述历史节原样保留。

### 实际身份与父子关系（注入事实，非计划 handle）

- 本子窗口：child task `task_02dd86ffb3f7`，dispatch `ctx_0c5994b7463b`，terminal handle `term_1dd8c35d-2034-436e-908d-bf371405991f`。
- 父任务 `task_0b49b1b287cb` / dispatch `ctx_555dcbf15135`（MEDIA Codex，term_56c18dc666859e62a33170c02d113469）；MAIN term_a731c232-35c7-4f55-a75d-9b2beeade398。
- 实际 checkout `/home/administrator/orca/workspaces/Narralens/Narralens-A-R1-MEDIA`；base `84deba07927fa59b45a24039b4740a2f9d3fd430`。
- 当前唯一 writer = 本 Claude 窗口（产品源码、测试、Git 索引、运行根）。父 Codex 在本窗口写入期间只读；Codex 未并发编辑任何文件/索引/运行根，本窗口亦未编辑 TASK/CLAUDE_IMPLEMENT/MAIN_START/ReleaseAssignment。
- 本窗口未开子 worker，未进 B，未读 ~/.claude/~/.codex/.env，未 dump env，未切供应商/模型，未安装依赖，未付费或外传。

### 已提交实现（显式 add 本票路径，未 push/merge/reset/stash）

| commit | 内容 |
|---|---|
| `24e3576d32385abedeb66d178fccee1e21228462` | 首批已锁共享类型（后被 01712e7 更正，保留为历史） |
| `01712e7bc29bcffb3a7f8dae201bccfd35170d17` | 更正：CompletedPreparedSourceV1 改用真实持久完成字段（terminal_reason SOURCE_ONLY、provider_receipt {kind local.native-draft@1, source_digest, stage SOURCE_ONLY}），去掉 result_ref 断言注释，plan_version 收窄为 1，preview 请求绑定/证明 purpose 收窄为 preview，proveForRead/assertCurrentForRead 按 purpose 泛型 |
| `e65d012bdb3980021029dd59faf23d373b2c68e4` | 目的分离的 read/adoption 证明 + 隔离 PreviewPreparedSource + 受控 reader；PreparedSourceProofPort 增加 release/close |

未提交（待收尾显式提交）：`tests/agent-driven/integration/created-draft-processor.test.ts`（新增 M17 证明 case + 诊断输出改到本票私有 evidence 目录）、`tests/agent-driven/media/preview-prepared-source.test.ts`（新建）。

### 命令证据（cwd 固定为本 checkout；logs/*.meta.json 含 argv/起止时间/exit/log SHA256）

| 命令 | 起止 | exit | log SHA256 |
|---|---|---|---|
| `corepack pnpm exec tsc --noEmit` | 2026-11-11T22:09:40+08:00 → 22:09:48+08:00 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`（日志为空，tsc 静默） |
| `corepack pnpm test tests/agent-driven/media/native-draft.test.ts tests/agent-driven/integration/source-digest-resource-boundary.test.ts --maxWorkers=1 --minWorkers=1` | 2026-11-11T22:20:48+08:00 → 22:20:50+08:00 | 0 | `ba53e5f7dcad80fd709dd9b263605ac32be63bbc8ad84ccfe420bb86a6944859` |

诚实说明：早于 22:09:40 的几次 `tsc --noEmit`（基线 84deba0、类型候选 24e3576、更正 01712e7）在会话内观察到 exit 0，但当时未把输出落盘，故无独立日志文件与 SHA；第一条有留痕的记录是 `logs/tsc-after-proof-ports.*`。不伪造此前的时间或输出。

### 逐 case 结论

| case | 结论 | 证据 |
|---|---|---|
| 全树 typecheck（含本票 4 个源文件 + 2 个测试文件） | PASS | logs/tsc-after-proof-ports.* |
| native-draft 纯单元 16 case + source-digest 资源边界 3 case | PASS（19/19） | logs/vitest-lightweight-unit.* |
| M17：SOURCE_ONLY 成功后 lease 已释放仍可复证、read 证明不得用于 adoption、换 binding/伪 JSON/异步回调/当前 author 变化均拒绝、释放后证明失效、FD 回收 | NOT_RUN | 需要真实 Host+ffmpeg，等待 MAIN 重型单槽 |
| M17 负向：同尺寸篡改 bytes 后拒绝复证 | NOT_RUN | 同上 |
| M02/M16：隔离副本真实预览、五 part 真实字节 receipt、真实 fps/帧数/audio 样本事实、受控 reader 与 Range/越界/幂等 close、原准备树与 author 无写 | NOT_RUN | 需要 Chromium+ffmpeg，等待 MAIN 重型单槽 |
| CR8 负向：伪报 fps、缺事实、错 object、metadata→bytes 间对象变化 | NOT_RUN | 同上 |

未运行的原因：MAIN 全机重型单槽尚未实际授予（已向父 Codex 申请，msg_202a12a2ccd3）。未获实际 slot 前不运行，不以组件/fixture 冒充真实媒体验收。

### 生产接缝的真实状态

- 真实消费者尚未接线：BRIDGE 侧 created-source-adoption-service / review-media 注册与 HTTP、PRODUCT 侧播放器与 `review.part.describe` 均为后续票据；本票只交付 Host-only 类型、证明与预览模块。接口需求已通过类型候选向 MAIN/父 Codex 报告，未重定义协议。
- 缺真实能力时保持不可用：预览需要真实 Chromium+ffmpeg 探测，缺任一能力即 CAPABILITY_UNAVAILABLE，不注入测试替身。

### 过程与恢复

- 无 429，无凭据读取，无子进程遗留（本次仅 vitest/tsc/ffmpeg 短命令，均已随命令结束）。
- 失败保留：TypeScript 早期两次编译错误（`known`/`expected` 未随重构改名）已如实修复并保留在提交历史中，未改超时或 guard 躲红灯。
- 回退：仅新增本票私有未发布副本与日志；不 reset/stash 用户工作，不删原准备树，不覆盖旧历史捕获。

### 本节自签边界

以上为实施者自测与组件证据，不签独立外审、不签 A 全链 PASS、不签人工验收。B 未进入。


## 第二轮更正（2026-11-11，父 Codex 只读复核后的定点更正）

复核发现的 7 组具体缺陷已在本轮一次性修正并补回归 case；当前候选已冻结，未获新重型槽前不运行重型测试。

### 冻结报告

- HEAD `c7745de34282223f0a7ead89f510559a87173a40`（base `84deba07927fa59b45a24039b4740a2f9d3fd430`）；dirty 仅本票未跟踪文档与日志目录，无 tracked 差异、无 index 改动。
- 重型测试输入（两个文件）SHA256：
  - `tests/agent-driven/integration/created-draft-processor.test.ts` = `aa463077083021c42e1705993b37a9811a0861c79c07eb5befeac2e97aae8fd5`
  - `tests/agent-driven/media/preview-prepared-source.test.ts` = `38ae72afdf7283b85c712aaa8c599ce51c231cd49739232010664aff450db050`
- 实现文件 SHA256：`assembly-ports.ts` = `5d216cb00662bb002ba44b18a4c15dced7c90e27d88d8c0162d81926d4ef1c67`；`prepared-draft-verifier.ts` = `f69770afba85137d0dfd7a33be6115093538a411c2a4308295b523a018bbe93f`；`created-draft-processor.ts` = `bafb71ffdbf41aab2f2d7779bfa0f42e0127ccee661f7a3631b0427220c62de2`；`preview-prepared-source.ts` = `899a9ba191b876492c663aae1785d20cac3b4239b4b1b148006e9a4a67cb0662`。
- 待授权命令（仅此一条）：`corepack pnpm test tests/agent-driven/integration/created-draft-processor.test.ts tests/agent-driven/media/preview-prepared-source.test.ts --maxWorkers=1 --minWorkers=1`，cwd = 本 checkout。

### 本轮逐条修正

1. verifier：binding 的 `source_digest` 改为对照 `task.request.source_digest`（当前作者基线），prepared 摘要仍由 `completed.fact.source_digest` 承担；binding 的 execution 必须与生产者 execution 逐字段相等（lease 重试是 lease attempt，不是 CP execution attempt 的变化）；`completedSource` 增加 `job.project_id` 校验；最终 assert 增加 `record.root === completedRoot` 与 `record.producerAttempt === completed.producer_attempt`，证明后的 root/attempt 被改动即拒绝。
2. preview：`protectedRoots` 真正生效——workspace/object 域与 protectedRoots、prepared root、pinned upstream 全部做双向包含检查，构造期与运行期各一次；域必须是锚定的私有目录（逐级 lstat 拒绝 symlink 祖先，终点需 0700+属主），新建目录保留 identity 用于清理；IsolatedCopy 为每个文件的全部祖先建目录，修掉 assets/vo 无 assets 直属文件时的父目录缺失。
3. preview 取消与收尾：发布前与每次发布前检查 signal.aborted、服务 closed，并重新做一次 proof/author/rights 同步断言；`close()` 置 closed 并 await 在途工作；`NativeRenderError.group_settled===false` 时保留自有 staging（记入 `retainedStaging()`）而非无条件删除，错误码保留在 ProductError 信息中。
4. reader：打开前重算 receipt_digest 并比对（receipt 被改即拒）；每次 read 前复检 fd 与路径的 fingerprint（对象被改写或替换即拒）；open 之后仍尊重 abort；metadata 深冻结；按 slot 校验 content_type 与 media_facts 的允许表；对象域做锚定私有校验。
5. 内容类型：shot_summary 改为真实 JSON（kind=json），subtitles=`text/vtt; charset=utf-8`，shot_summary/rights_quality=`application/json; charset=utf-8`，preview=`video/mp4`，narration 沿用注册的真实音频类型。
6. 帧率与样本：不再用 avg==r 声称 CFR，改为读取解码后的每帧 `pts_time`，逐帧步长必须等于计划步长（1% 容差）且帧数一致，否则不给 receipt；旁白 sample_count 改为解码到真实 PCM 后按字节数计得样本数，并校验换算帧数等于计划帧数，不一致即拒。
7. 回归 case：新增 binding 基线/执行/prepared_job/root/producer_attempt 的拒绝断言；新增预览拒绝 case（错误基线、被改 root、取消后不发布任何对象、close 后拒绝、与 protected 域重叠的 workspace/object 域被拒、slot 不允许的 content_type 与 media_facts 被拒）。

### 本轮命令证据（同一记录器，logs/*.meta.json）

| 命令 | 起止 | exit | log SHA256 |
|---|---|---|---|
| `corepack pnpm exec tsc --noEmit` | 2026-11-11T22:37:28+08:00 → 22:37:35+08:00 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`（日志为空） |
| `corepack pnpm test tests/architecture --maxWorkers=1 --minWorkers=1` | 2026-11-11T22:36:43+08:00 → 22:36:44+08:00 | 1 | `aeed168668d40176cdee84f40fe3ea7a6beea2542f839fcdfe769081acbbd105` |

架构 fitness 仍是同一批既有红灯：m2.2 规则 1 与 13 的 offender 仍是 `src/host/projects/project-creation-store.ts` 与 `src/host/agent-driven/created-task-store.ts`，这两个文件自 base 84deba0 起未被本票改动（`git diff 84deba0..HEAD -- <两文件>` 为空），两次日志的 offender 集合逐行相同；m2.1 依赖方向 22 case 全 PASS，新增文件与其 import 未越层。本票不修改这两个文件（不在 12 路径白名单内），如实保留为既有红灯并上报 MAIN。

### 仍未运行

M17 全部 case、M02/M16 隔离预览 case、CR8 负向：仍为 NOT_RUN，等待 MAIN 新的全机重型单槽授权；在获得实际授权前不运行，不以组件/fixture 冒充真实媒体或人工验收。


### 冻结报告更正（同一轮，唯一后续提交）

上节冻结报告之后只落了一个后续提交：HEAD 由 `c7745de34282223f0a7ead89f510559a87173a40` 变为 `c8a06729c2a58d0e79c40042f3155c558ca6fd11`，只改 `src/host/render/preview-prepared-source.ts`（Host 未预建 preview workspace 根时由服务私有创建，而不是因缺父目录失败）。两个重型测试输入哈希不变（`aa463077083021c42e1705993b37a9811a0861c79c07eb5befeac2e97aae8fd5`、`38ae72afdf7283b85c712aaa8c599ce51c231cd49739232010664aff450db050`）；变更后的实现文件哈希 `src/host/render/preview-prepared-source.ts` = `7fd0a779b3560b96b63780e856fa34b8895b6694aaac11b0bd5525e472880b4c`，其余三个实现文件哈希不变。`corepack pnpm exec tsc --noEmit` 在该树上 exit 0；无 tracked 差异、无 index 改动。旧授权已撤回，未在其下运行任何重型命令；新授权到达前不运行。


## MAIN 重型槽 R1-MEDIA-PREVIEW-002 实跑结果（2026-11-11，exit 1）

授权命令（仅此一条，cwd = 本 checkout）：`corepack pnpm test tests/agent-driven/integration/created-draft-processor.test.ts tests/agent-driven/media/preview-prepared-source.test.ts --maxWorkers=1 --minWorkers=1`

- 运行 shell PID 843786；起 2026-11-11T22:44:10+08:00，止 22:45:28+08:00；exit 1；原始日志 `logs/vitest-heavy-preview-002.log` SHA256 `77e755754ad34b9db017ed6219043137224bea98a7e140c8679d5a51cd7580b2`（6474 字节）；元数据 `logs/vitest-heavy-preview-002.meta.json`。
- 运行前核验：HEAD = `c8a06729c2a58d0e79c40042f3155c558ca6fd11`；tracked diff 空、index diff 空；六个源/测试文件哈希与冻结报告一致；运行前无遗留 chrome/ffmpeg/vitest 进程。

### 逐文件结论

| 文件 | 结果 | 说明 |
|---|---|---|
| `tests/agent-driven/integration/created-draft-processor.test.ts` | PASS 7/7，47505 ms | 含新增 M17 两例：`re-proves a succeeded SOURCE_ONLY source without a live lease and keeps the read proof away from the adoption assertion`、`refuses a read proof of prepared bytes that changed under the same size and closes its descriptors`。真实 Host+ffmpeg，read/adoption 证明在真实 processor 路径上成立。 |
| `tests/agent-driven/media/preview-prepared-source.test.ts` | FAIL 4/4，24234 ms | 四个 case 全部在**测试 fixture** 的 `verifier.prove()` 处失败（`Prepared native source verification could not complete`），在任何 preview 渲染之前。产品代码路径未被触达。 |

### 失败的准确原因（留给 MAIN 根因归属）

fixture 用 assembler 的原始 draft 去 `verifier.prove()`；verifier 的 `#prove` 要求 prepared 闭包包含 Host 写入的 `prepared-native.json`（`roots.includes(META)` 与其精确键集），而该元数据由 `created-draft-processor.ts` 的私有 `#metadata()` 在 prove 之前写入并扩展 draft 的 roots/files。preview lane 的 fixture 没有走这一步，因此被正确拒绝。

根因候选（供 MAIN 判断，不在本轮自行修改）：prepared 输出的“写元数据 + 出证明”这一步目前只存在于 processor 的私有方法里，第二个生产者（preview lane 的 fixture、以及后续 BRIDGE 的采用服务）没有受支持的方式产出一个可被证明的 prepared source；是否把这一步抽成 MEDIA lane 共享单元（例如已在本票白名单内的 `src/host/render/native-draft-io.ts`）由 MAIN 决定。

按父 Codex 指示：这是第三次返工，MAIN 接管根因归属；本窗口作为唯一指派但**已停止写入**，保留候选 `c8a06729c2a58d0e79c40042f3155c558ca6fd11`、全部失败日志与清理证据，不自行实现该 fixture 修复、不再发起重型检查、不自签成功。

### 清理证据（具体，非保证）

见 `evidence/cleanup-20261111-224528.txt`：运行 shell PID 843786 与 vitest worker PID 843848 均已不存在；进程表中无本次运行遗留的 chrome/ffmpeg/ffprobe/vitest/openfilm-render-worker；本次运行三个 PID 均无监听套接字；四个失败 case 泄漏的临时工作区（`/tmp/narralens-created-workspace-6LqVZ2`、`-GpQLIR`、`-leGcpV`、`-tNaqkV`，各含 `prepared-preview/`）已按“只清本任务未发布副本”删除，当前无任何 `/tmp/narralens-*` 残留；通过的 processor case 写入本票私有证据 `evidence/draft-processor-real-1794408261304/`（observed.json / film.html / diagnostic.wav，SHA256 80a00695…、1ec8a5ee…、42c9992d…）。诊断媒体为合成 fixture，不是真实 A 人验素材。


## MAIN rework3生产缺陷补充（2026-11-11）

来源：MAIN消息msg_d8c031cb7e0b；MAIN在其集成目录只读诊断后实施修正，MEDIA本地仍冻结c8a06729c2a58d0e79c40042f3155c558ca6fd11，无本lane源码/测试/索引改动。

MAIN确认preview生产probeVideo将实际PTS秒差与expected.num/expected.den比较，30fps因此错误要求30秒帧间隔；正确应为expected.den/expected.num，即1/30秒。原四项测试在缺metadata的fixture处失败，隐藏了此生产缺陷，不能将那次fixture失败解释为已交代码正确。MAIN已报告在集成目录修正倒数，并在复用真实processor的preview测试增加rights_quality实际解码时间间隔断言；本lane未运行或独立验证该修正，不签PASS。

MAIN先前msg_62fd132e4e83的fixture修复使用实际CreatedDraftTaskProcessor/CreatedTaskStore/worker、真实持久job/provider receipt/fact与原私有metadata路径，形成测试共享helper而非第二生产metadata writer；原三镜计划为90frames/144000 audio samples，断言绑定真实计划。fixture eligibility/TestAdoptionAuthority仍为组件测试端口，合成媒体不是A真实人声影片证据。

原R1-MEDIA-PREVIEW-002 exit1、7PASS/4fixtureFAIL、原candidate及日志/清理记录全部保留。其他proof/reader/lifecycle由MAIN继续审核，生产预览仍未证实；MEDIA与Claude保持source/test/index停写，无额外重试/重型命令。此前CLAUDE“缺陷只在fixture”的说法是被本节纠正的历史作者判断。


## 子任务正式结算与父票交回

收到Orca worker_done msg_b4ace1702557：child task_02dd86ffb3f7 / ctx_0c5994b7463b，outcome=failed，冻结c8a06729c2a58d0e79c40042f3155c558ca6fd11。唯一子任务已settled，无其他helper；保留keep-open窗口，writer停止。父票task_0b49b1b287cb / ctx_555dcbf15135同样以未完成failed交回MAIN，不冒称目标已实现。模块7PASS/预览4fixtureFAIL与随后MAIN发现CFR倒数生产缺陷均保留；MAIN拥有第三轮fixture/生产修复及后续验证。MEDIA本地source/test/index继续冻结，无新执行授权。
