#!/usr/bin/env bash
# A-R1-MEDIA: run one command and record cwd, argv, start/end time, exit and the
# SHA256 of its captured output under this ticket's own logs directory.
# Usage: run-ticket-command.sh <log-name> <command> [args...]
set -uo pipefail
TICKET_DIR="$(cd "$(dirname "$0")" && pwd)"
NAME="$1"; shift
LOG_DIR="$TICKET_DIR/logs"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/${NAME}.log"
META="$LOG_DIR/${NAME}.meta.json"
START="$(date -Is)"
START_EPOCH="$(date +%s)"
"$@" >"$LOG" 2>&1
EXIT=$?
END="$(date -Is)"
END_EPOCH="$(date +%s)"
SHA="$(sha256sum "$LOG" | cut -d' ' -f1)"
python3 -I - "$META" "$NAME" "$START" "$END" "$EXIT" "$SHA" "$LOG_DIR" "$PWD" "$@" <<'PY'
import json,sys
meta,name,start,end,exit_code,sha,log_dir,cwd=sys.argv[1:9]
argv=sys.argv[9:]
payload={"ticket":"A-R1-MEDIA","name":name,"cwd":cwd,"argv":argv,
 "started_at":start,"ended_at":end,"exit_code":int(exit_code),
 "log_file":log_dir.rsplit('/',1)[-1]+'/'+name+'.log',"log_sha256":sha,
 "log_bytes":None,"note":"captured by run-ticket-command.sh; stdout and stderr are merged in log_file"}
import os
payload["log_bytes"]=os.path.getsize(log_dir+'/'+name+'.log')
with open(meta,'w',encoding='utf-8') as handle:
    handle.write(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(payload,ensure_ascii=False))
PY
exit "$EXIT"
